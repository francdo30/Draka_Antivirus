﻿using System.Collections.Generic;

namespace Draka_Antivirus.Pages_Principales
{
    interface IPassReader
    {
        IEnumerable<CredentialModel> ReadPasswords();
        string BrowserName { get; }
    }
}
