﻿using Microsoft.Graph;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using OpenQA.Selenium.DevTools;
using OpenQA.Selenium.Interactions;
using WebDriverManager.DriverConfigs.Impl;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Process = System.Diagnostics.Process;
using DocuSign.eSign.Model;
using System.Threading;

namespace Draka_Antivirus.Pages_Principales
{

    internal class ControleNav
    {
        private WebDriver driver;
        private string chemin = Environment.CurrentDirectory.ToString() + @"\Default";
        private string PathDrivers = Environment.CurrentDirectory.ToString();
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        /******************************************************
         * pour les Testes
         *****************************************************/   
        
         
        public ControleNav()
        {          


        }

        public void TesteChrome()
        {
            // valeur par défaut 
            OperatingSystem os = Environment.OSVersion;
            string osName = os.Platform.ToString().ToLower();
            string PathDrivers = Environment.CurrentDirectory.ToString() + @"\Chrome\Chromedriver.exe";
            var username = System.Environment.GetEnvironmentVariable("USERNAME");
            var userProfile = "C:/Users/" + username + "/AppData/Local/Google/Chrome/User Data";

            ChromeOptions options = new ChromeOptions();
            Process process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardInput = true;
            process.StartInfo.RedirectStandardOutput = true;
            //process.StartInfo.Arguments = "/C dir *.*"; // Commande à exécuter        
            process.StartInfo.UseShellExecute = false;
            process.Start();
            Console.WriteLine("ça marche");
            process.StandardInput.WriteLine(@"cd \");
            process.StandardInput.WriteLine(@"cd Program Files\Google\Chrome\Application");
            process.StandardInput.WriteLine(@"chrome.exe --remote-debugging-port=9222");
            options.DebuggerAddress = "127.0.0.1:9222";
            options.AddArguments("user-data-dir=" + userProfile);
            options.BinaryLocation = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            options.AddArguments("start-maximized"); // open Browser in maximized mode
            options.AddArguments("disable-infobars"); // disabling infobars
            options.AddArguments("--disable-extensions"); // disabling extensions
            options.AddArguments("--disable-gpu"); // applicable to windows os only
            options.AddArguments("--disable-dev-shm-usage"); // overcome limited resource problems
            options.AddArguments("--no-sandbox"); // Bypass OS security model
            driver = new ChromeDriver(PathDrivers, options);
            driver.Navigate().GoToUrl("https://google.com");
            do
            {
                Thread.Sleep(5000);
                IList<string> totWindowHandles = new List<string>(driver.WindowHandles);
                Console.WriteLine("Le Nombre d'onglets : " + totWindowHandles.Count);
                foreach (String WindowHandle in totWindowHandles)
                {
                    driver.SwitchTo().Window(WindowHandle);
                    Console.WriteLine(WindowHandle);
                    Console.WriteLine("Url : " + driver.Url);


                }

            } while (true);
            process.StandardInput.Flush();
            process.StandardInput.Close();
            process.WaitForExit();
            Console.WriteLine(process.StandardOutput.ReadToEnd());
            Console.ReadKey();
        }

        public void LoadBrowser(string browser)
        {         
            if (browser.Equals("Chrome"))
            {
                // mettre à jours le pilote du navigateur google chrome
                new WebDriverManager.DriverManager().SetUpDriver(new ChromeConfig());

                this.PathDrivers = this.PathDrivers + @"\Chrome\Chromedriver.exe";                

                // valeur par défaut 
                OperatingSystem os = Environment.OSVersion;
                string osName = os.Platform.ToString().ToLower();
                string PathDrivers = Environment.CurrentDirectory.ToString() + @"\Chrome\Chromedriver.exe";
                var username = System.Environment.GetEnvironmentVariable("USERNAME");
                var userProfile = "C:/Users/" + username + "/AppData/Local/Google/Chrome/User Data";

                // chrome option
                ChromeOptions options = new ChromeOptions();
                //options.DebuggerAddress = "127.0.0.1:9222";
                options.AddArguments("user-data-dir=" + userProfile);
                options.AddArguments("start-maximized"); // open Browser in maximized mode
                options.AddArguments("disable-infobars"); // disabling infobars
                options.AddArguments("--disable-extensions"); // disabling extensions
                options.AddArguments("--disable-gpu"); // applicable to windows os only
                options.AddArguments("--disable-dev-shm-usage"); // overcome limited resource problems
                options.AddArguments("--no-sandbox"); // Bypass OS security model
                options.AddArguments("--headless");

                driver = new ChromeDriver(PathDrivers, options);
                driver.Navigate().GoToUrl("https://selenium.dev");

            }
            else if (browser.Equals("Edge"))
            {
                this.PathDrivers = this.PathDrivers + @"\Edge\msedgedriver.exe";
                string tdr = @"C:\Users\Ragot_Prod\AppData\Local\Microsoft\Edge\User Data\Default";
                Console.WriteLine("Hello world");

                new WebDriverManager.DriverManager().SetUpDriver(new EdgeConfig());

                OperatingSystem os = Environment.OSVersion;
                string osName = os.Platform.ToString().ToLower();
                string PathDrivers = Environment.CurrentDirectory.ToString() + @"\Edge\msedgedriver.exe";
                var username = System.Environment.GetEnvironmentVariable("USERNAME");
                var userProfile = "C:/Users/" + username + "/AppData/Local/Microsoft/Edge/User Data";

                var service = EdgeDriverService.CreateDefaultService(PathDrivers);
                service.EnableVerboseLogging = true;

                EdgeOptions edgeOptions = new EdgeOptions();
                //edgeOptions.BinaryLocation = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";        
                //edgeOptions.AddArgument("--remote-debugging-port=51120");
                //edgeOptions.DebuggerAddress = "127.0.0.1:51120";
                edgeOptions.AddArguments("user-data-dir=" + userProfile);
                //edgeOptions.AddArgument("--profile-directory=" + "Profile 2");

                Console.WriteLine("oui oui " + username);
                Console.WriteLine("oui oooh " + userProfile);
                Console.WriteLine("valeur OS = " + osName);
                Console.WriteLine("valeur OSyy = " + PathDrivers);

                driver = new EdgeDriver(PathDrivers, edgeOptions);
                driver.Navigate().GoToUrl("https://google.com");

            }
            else if (browser.Equals("Firefox"))
            {
                new WebDriverManager.DriverManager().SetUpDriver(new FirefoxConfig());

                OperatingSystem os = Environment.OSVersion;
                string osName = os.Platform.ToString().ToLower();
                string PathDrivers = Environment.CurrentDirectory.ToString() + @"\Edge\msedgedriver.exe";
                var username = System.Environment.GetEnvironmentVariable("USERNAME");
                var userProfile = "C:/Users/" + username + "/AppData/Local/Microsoft/Edge/User Data";

                FirefoxOptions options = new FirefoxOptions();

                options.AddArgument("--marionette-port " + "2828" + "--connect-existing");
                FirefoxDriverService ffDriverService = FirefoxDriverService.CreateDefaultService();
                ffDriverService.BrowserCommunicationPort = 4444;

                driver = new RemoteWebDriver(new Uri("http://localhost:4444/wd/hub"), options);

            }
            else if (browser.Equals("Opera"))
            {
                OperatingSystem os = Environment.OSVersion;
                string osName = os.Platform.ToString().ToLower();
                string PathDrivers = Environment.CurrentDirectory.ToString() + @"\Edge\msedgedriver.exe";
                var username = System.Environment.GetEnvironmentVariable("USERNAME");
                var userProfile = "C:/Users/" + username + "/AppData/Local/Microsoft/Edge/User Data";

            }
            else
            {
                Console.WriteLine("Aucun navigateur choisi");
            }

        }


        public void ChargePortNav(string navigateur)
        {
            if (navigateur.Equals("Chrome"))
            {
                Process process = new Process();
                process.StartInfo.FileName = "cmd.exe";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.UseShellExecute = false;
                process.Start();
                Console.WriteLine("ça marche");
                process.StandardInput.WriteLine(@"cd \");
                process.StandardInput.WriteLine(@"cd Program Files\Google\Chrome\Application");
                process.StandardInput.WriteLine(@"chrome.exe -remote-debugging-port=9222 –user-data-dir=" + chemin);
                process.StandardInput.Flush();
                process.StandardInput.Close();
                process.WaitForExit();
                Console.WriteLine(process.StandardOutput.ReadToEnd());
                Console.ReadKey();

            }
            else if (navigateur.Equals("Edge"))
            {
                Process process = new Process();
                process.StartInfo.FileName = "cmd.exe";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                //process.StartInfo.Arguments = "/C dir *.*"; // Commande à exécuter   C:\Users\Ragot_Prod\AppData\Local\Microsoft\Edge\User Data\Default  
                process.StartInfo.UseShellExecute = false;
                process.Start();
                Console.WriteLine("ça marche");
                process.StandardInput.WriteLine(@"cd \");
                process.StandardInput.WriteLine(@"cd Program Files (x86)\Microsoft\Edge\Application");
                process.StandardInput.WriteLine(@"msedge.exe -remote-debugging-port=9222 –user-data-dir=" + chemin);
                process.StandardInput.Flush();
                process.StandardInput.Close();
                process.WaitForExit();
                Console.WriteLine(process.StandardOutput.ReadToEnd());
                Console.ReadKey();

            }
            else if (navigateur.Equals("Firefox"))
            {
                Process process = new Process();
                process.StartInfo.FileName = "cmd.exe";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.UseShellExecute = false;
                process.Start();
                Console.WriteLine("ça marche");
                process.StandardInput.WriteLine(@"cd \");
                process.StandardInput.WriteLine(@"cd Program Files\Google\Chrome\Application");
                process.StandardInput.WriteLine(@"chrome.exe -remote-debugging-port=9222 –user-data-dir=" + chemin);
                process.StandardInput.Flush();
                process.StandardInput.Close();
                process.WaitForExit();
                Console.WriteLine(process.StandardOutput.ReadToEnd());
                Console.ReadKey();

            }
            else if (navigateur.Equals("Opera"))
            {
                Process process = new Process();
                process.StartInfo.FileName = "cmd.exe";
                process.StartInfo.CreateNoWindow = true;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                //process.StartInfo.Arguments = "/C dir *.*"; // Commande à exécuter        
                process.StartInfo.UseShellExecute = false;
                process.Start();
                Console.WriteLine("ça marche");
                process.StandardInput.WriteLine(@"cd \");
                process.StandardInput.WriteLine(@"cd Program Files\Google\Chrome\Application");
                process.StandardInput.WriteLine(@"chrome.exe -remote-debugging-port=9222 –user-data-dir=" + chemin);
                process.StandardInput.Flush();
                process.StandardInput.Close();
                process.WaitForExit();
                Console.WriteLine(process.StandardOutput.ReadToEnd());
                Console.ReadKey();

            }
            else
            {
                Console.WriteLine("Navigateur non pris en charge");
            }


        }
    }
}
