﻿using Draka_Antivirus.DAO;
using Draka_Antivirus.Windows;
using OpenQA.Selenium.Chrome;
using System;
using System.Diagnostics;
using System.IO;
/*using System.Windows.Automation; */ 
using System.Windows.Forms;

namespace Draka_Antivirus.Pages_Principales
{
    internal class Ojectionnalwebsite
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "objectionable_websites.db";
        public static string sourceFile = targetPath + name_db;
        Database db1 = new Database();
        private bool responseIsUrl;
        ObjectionableWebsites control = new ObjectionableWebsites();
        string path = @"D:\job\AGMA Organization technology inc\Draka new verison\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
        /*string path = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";*/
        /*string path = @"C:\Program Files (x86)\Default Company Name\Setup1\Error_Log.txt";*/

        //Get url enter by client
        public string getChromeUrlBrowser()
        {
            string url = "";
            // there are always multiple chrome processes, so we have to loop through all of them to find the
            // process with a Window Handle and an automation element of name "Address and search bar"
            Process[] procsChrome = Process.GetProcessesByName("chrome");
            foreach (Process chrome in procsChrome)
            {
                // the chrome process must have a window
                if (chrome.MainWindowHandle == IntPtr.Zero)
                {
                    continue;
                }

                // find the automation element
                 
                /*AutomationElement elm = AutomationElement.FromHandle(chrome.MainWindowHandle);
                AutomationElement elmUrlBar = elm.FindFirst(TreeScope.Descendants,
                  new PropertyCondition(AutomationElement.NameProperty, "Address and search bar"));  

                // if it can be found, get the value from the URL bar
                if (elmUrlBar != null)
                {
                    AutomationPattern[] patterns = elmUrlBar.GetSupportedPatterns();
                    if (patterns.Length > 0)
                    {
                        ValuePattern val = (ValuePattern)elmUrlBar.GetCurrentPattern(patterns[0]);
                        url = val.Current.Value;
                    } 
                }*/
            }
            return url;
        }

        // system will perform parental control if is active
        public void BaseVirale(String activate)
        {
            string parentControl = "active";
            string status = "";
            string url = "";
            string url1 = "";
            Uri uri;

            do
            {
                /*url = getChromeUrlBrowser();
                responseIsUrl = control.isURL(url);*/

            } while (responseIsUrl == false);

            if (activate == parentControl)
            {
                // je recupere le nom de domaine de l'url recuperer dans le browser
                uri = new Uri(url);
                url1 = uri.Host;
                // j'effectue une recherche du nom de domaine et le statut dans la base de donnee
                try
                {
                    // Nous recherchons l'url dans la base de donnee
                    Object[] dburl = db1.searchData(sourceFile, "select url from viralbase where url='" + url1 + "';");

                    // verification de l'Object dburl
                    if (dburl != null && url1.Equals(dburl[0].ToString()))
                    {
                        AutoClosingMessageBox.Show("Site est a haut risque et dangereux \n Veuillez quitter de ce site", "Patientez", 2000);
                        // Nous configurons les elements de la base de donnee websites
                        status = "site haut rique";
                        DateTime date = DateTime.Now;
                        string date_str = date.ToString("dd/MM/yyyy HH:mm:ss");
                        url1 = "htpp://" + url1;
                        string sql = "insert into websites (url, status, date) values(";
                        sql = sql + "'" + url1 + "', ";
                        sql = sql + "'" + status + "', ";
                        sql = sql + "'" + date_str + "')";

                        try
                        {
                            // Insertions de l'url en base de donnee
                            Boolean error = db1.insertData(sourceFile, sql);
                        }
                        catch (Exception e)
                        {
                            if (!File.Exists(path))
                            {
                                File.Create(path);
                                TextWriter tw = new StreamWriter(path, true);
                                tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                tw.Close();
                            }

                            else if (File.Exists(path))
                            {
                                TextWriter tw = new StreamWriter(path, true);
                                tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                tw.Close();
                            }
                        }
                    }
                    else
                    {
                        AutoClosingMessageBox.Show("Vous visiter ce site : " + url1 + "\n Mais nous vous recommendons d'etre prudent", "Patientez", 2000);
                        // Nous configurons les elements de la base de donnee websites
                        status = "Site Visiter";
                        DateTime date = DateTime.Now;
                        string date_str = date.ToString("dd/MM/yyyy HH:mm:ss");
                        url1 = "htpp://" + url1;
                        string sql = "insert into websites (url, status, date) values(";
                        sql = sql + "'" + url1 + "', ";
                        sql = sql + "'" + status + "', ";
                        sql = sql + "'" + date_str + "')";

                        try
                        {
                            // Insertions de l'url en base de donnee
                            Boolean error = db1.insertData(sourceFile, sql);
                        }
                        catch (Exception e)
                        {
                            if (!File.Exists(path))
                            {
                                File.Create(path);
                                TextWriter tw = new StreamWriter(path, true);
                                tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                tw.Close();
                            }

                            else if (File.Exists(path))
                            {
                                TextWriter tw = new StreamWriter(path, true);
                                tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                tw.Close();
                            }
                        }
                    }

                }
                catch (Exception e)
                {
                    if (!File.Exists(path))
                    {
                        File.Create(path);
                        TextWriter tw = new StreamWriter(path, true);
                        tw.WriteLine(DateTime.Now.ToString() + " " + "Url_send:" + " " + url1 + " " + "Error_Message:" + e);
                        tw.Close();
                    }

                    else if (File.Exists(path))
                    {
                        TextWriter tw = new StreamWriter(path, true);
                        tw.WriteLine(DateTime.Now.ToString() + " " + "Url_send:" + " " + url1 + " " + "Error_Message:" + e);
                        tw.Close();
                    }
                }
            }
        }
    }
}
