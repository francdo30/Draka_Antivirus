﻿using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Management;
using System.Diagnostics;

namespace Draka_Antivirus.Pages_Principales
{
    internal class InfoSystem
    {
              
        double res;
        double fres;
        
        public List<String> WMI = new List<string>();
        public List<String> CommandeWMI()
        {
            //Connextion à l'interface WMI 

           ConnectionOptions options = new ConnectionOptions();
            //options.Username;
            //options.Password;
            ManagementScope scope = new ManagementScope("\\\\.\\root\\cimv2", options);

            //L'extraction des ressources 

            ObjectQuery query = new ObjectQuery("SELECT *FROM Win32_OperatingSystem");
            ObjectQuery query1 = new ObjectQuery("SELECT *FROM Win32_Processor");
            ObjectQuery query2 = new ObjectQuery("SELECT *FROM Win32_PhysicalMemory");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, query);
            ManagementObjectSearcher searcher1 = new ManagementObjectSearcher(scope, query1);
            ManagementObjectSearcher searcher2 = new ManagementObjectSearcher(scope, query2);

            //La gestion des propriétés des ressources.
            ManagementObjectCollection queryCollection = searcher.Get();
            ManagementObjectCollection queryCollection1 = searcher1.Get();
            ManagementObjectCollection queryCollection2 = searcher2.Get();
            foreach (ManagementObject obj in queryCollection)
            {
                // initialisation variable : Récupération des informations systeme
                res = Convert.ToDouble(obj["TotalVisibleMemorySize"].ToString());
                fres = Math.Round((res / (1024 * 1024)), 2);


                String OpS =     (String)obj["Caption"];
                WMI.Add(OpS);                //00
                //String Cname = "Computer Name : " + obj["CSName"].ToString();
                //String Uname = "User Name : " + Environment.UserName;
                String Tmenory =   fres + "Gb";
                WMI.Add(Tmenory);             //01
                String Arch =     (String)obj["OSArchitecture"];
                WMI.Add(Arch);                //02
                String Vsys =     (String)obj["Version"];
                WMI.Add(Vsys);                //03
                String Fabrican = (String)obj["Manufacturer"];
                WMI.Add(Fabrican);            //04
                String MotherBoard = "MotherBoard : ";
                WMI.Add(MotherBoard);         //05

            }
            // Recupération des informations du processeur

            foreach (ManagementObject pro in queryCollection1)
            {
                String NofCores =   pro["NumberOfCores"].ToString();
                WMI.Add(NofCores);             //06
                String ClockSpeed = pro["MaxClockSpeed"].ToString() + "MHz";
                WMI.Add(ClockSpeed);           //07
                String Processeur = pro["Name"].ToString();               
                WMI.Add(Processeur);           //08

            }

            var cpuUsage = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            String Pload = "";
            for (int i = 0; i < 5; i++)
            {
                Pload = cpuUsage.NextValue() + "%";                
            }
            WMI.Add(Pload);                 //09
            // le workGroup est extrait

            ManagementObjectSearcher mos = new ManagementObjectSearcher(@"root\CIMV2", @"SELECT * FROM Win32_ComputerSystem");
            foreach (ManagementObject mo in mos.Get())
            {
                String Dgroup = mo["Workgroup"].ToString();
                WMI.Add(Dgroup);                  //10

            }
            // Recupération des informations réseau

            foreach (ManagementObject pro in queryCollection2)
            {
                // Machine = pro["NumberOfCores"].ToString();
                
            }
                // Recupération des informations de la ROM

            foreach (ManagementObject pro in queryCollection2)
            {
                // Machine = pro["NumberOfCores"].ToString();
          
            }

            // Recupération des informations de la graphique

            ManagementObjectSearcher myVideoObject = new ManagementObjectSearcher("select * from Win32_VideoController");

            foreach (ManagementObject obj in myVideoObject.Get())
            {
                String Graphic = obj["Name"].ToString();
                WMI.Add(Graphic);                 //11
            } 
            return WMI;  
            
        }
    }
}
