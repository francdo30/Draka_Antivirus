﻿using Azure;
using Draka_Antivirus.DAO;
using Draka_Antivirus.Windows;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.IO;
/*using System.Windows.Automation;*/
using System.Windows.Forms;

namespace Draka_Antivirus.Pages_Principales
{
    class ParentalControl
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "ScanDataBase.db";
        //public static string name_db1 = "parentalControl.db";
       
        public static string targetPath1 = AppDomain.CurrentDomain.BaseDirectory;
        public static string sourceFile = targetPath + name_db;
        string PathDataVirale = targetPath1 + "viraldatabase.txt";
        string path = @"C:\Windows\System32\drivers\etc\hosts";
        Database db1 = new Database();
        ObjectionableWebsites control1 = new ObjectionableWebsites();
        private bool responseIsUrl;

        private string NewValue = @"C:\Draka_Antivirus\Draka_Antivirus\bin\Debug\shield\index.htm";
        //string path = @"C:\Draka_Antivirus\Draka_Antivirus\bin\Debug\Error_Log.txt";

        // For production
        /*private const string NewValue = @"C:\Program Files (x86)\Default Company Name\Setup1\shield\index.htm";*/
        /*string path = @"C:\Program Files (x86)\Default Company Name\Setup1\Error_Log.txt";*/

        // for test
        /*string path = @"D:\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
        private string NewValue = @"D:\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\shield\index.htm";*/



        //Create Database if not exit
        public void parentalData()
        {
            //creation de la table parentalControle
            db1.CreateTable(sourceFile, "parentControl");
        }

        // On obtient l'url entrer par le client
        public string getChromeUrlBrowser()
        {
            string url = ""; 

            // il y a toujours plusieurs processus de chrome, donc nous devons boucler à travers chacun d’entre eux pour trouver le
            // processus avec une poignée de fenêtre et un élément d’automatisation de nom "Adresse et barre de recherche"
           
            Process[] procsChrome = Process.GetProcessesByName("chrome");
            foreach (Process chrome in procsChrome)
            {
                // le processus de chrome doit avoir une fenêtre
                if (chrome.MainWindowHandle == IntPtr.Zero)
                {
                    continue;
                }

                // trouver l’élément d’automatisation
               /* AutomationElement elm = AutomationElement.FromHandle(chrome.MainWindowHandle);
                AutomationElement elmUrlBar = elm.FindFirst(TreeScope.Descendants,
                  new PropertyCondition(AutomationElement.NameProperty, "Address and search bar"));

                // si elle peut être trouvée, obtenir la valeur de la barre d’URL
                if (elmUrlBar != null)
                {
                    AutomationPattern[] patterns = elmUrlBar.GetSupportedPatterns();
                    if (patterns.Length > 0)
                    {
                        Console.WriteLine(patterns.Length);
                        ValuePattern val = (ValuePattern)elmUrlBar.GetCurrentPattern(patterns[0]);
                        url = val.Current.Value;
                    }

                }*/

            }

            return url;
        }
        // le système effectuera le contrôle parental si il est actif
        public void parentalControl(String activate)
        {
            string parentControl = "active";
            string status = "";
            string url = "";
            string url1 = "";
            string url2 = "";
            Uri uri;

            do
            {
                url = getChromeUrlBrowser();
                /*responseIsUrl = control1.isURL(url); */

            } while (responseIsUrl == false);

            if (activate == parentControl)
            {
                // je recupere le nom de domaine de l'url recuperer dans le browser
                uri = new Uri(url);
                url1 = uri.Host;
                // j'effectue une recherche du nom de domaine et le statut dans la base de donnee
                string url3 = "http://" + url1;

                ChromeDriver driver = new ChromeDriver(@"C:\Draka_Antivirus\Draka_Antivirus\bin\Debug\Error_Log.txt");
                // test
                /*ChromeDriver driver = new ChromeDriver(@"D:\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug");*/
                /*ChromeDriver driver = new ChromeDriver(@"C:\Program Files (x86)\Default Company Name\Setup1");*/

                // On essaie une connexion a la base de donnee pour recuperer l'url correspondant
                try
                {
                    Object[] dburl = db1.searchData(sourceFile, "select url, status from parentControl where url='" + url3 + "';");
                    // Nous verifions d'abord que l'Object dburl n'est pas vide
                    if (dburl != null)
                    {
                        url2 = dburl[0].ToString();
                        status = dburl[1].ToString();

                        // on teste la compatibiliter
                        if (url3.Equals(url2) && status.Equals("Bad"))
                        {
                            String path = @"C:\Windows\System32\drivers\etc\hosts";
                            StreamWriter sw = new StreamWriter(path, true);
                            String sitetoblock = "127.0.0.1 " + url1;
                            sw.Write(sitetoblock);
                            sw.Close();


                            driver.Navigate().GoToUrl(NewValue);
                            System.Threading.Thread.Sleep(30000);

                        }
                        else
                        {
                            status = "Site visitor";
                            DateTime date = DateTime.Now;
                            string date_str = date.ToString("dd/MM/yyyy HH:mm:ss");
                            string sql = "insert into parentControl (url, status, date) values(";
                            sql = sql + "'" + url3 + "', ";
                            sql = sql + "'" + status + "', ";
                            sql = sql + "'" + date_str + "')";

                            try
                            {
                                Boolean error = db1.insertData(sourceFile, sql);

                                if (error == true)
                                {
                                    AutoClosingMessageBox.Show(" Site sécurisé", "Internal Message", 2000);
                                }
                                else
                                {
                                    AutoClosingMessageBox.Show("Site deja visiter ", "Internal Message", 2000);
                                }
                            }
                            catch (Exception e)
                            {
                                if (!File.Exists(path))
                                {
                                    File.Create(path);
                                    TextWriter tw = new StreamWriter(path, true);
                                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                    tw.Close();
                                }
                                else if (File.Exists(path))
                                {
                                    TextWriter tw = new StreamWriter(path, true);
                                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + e);
                                    tw.Close();
                                }
                            }

                        }
                    }
                }
                catch (Exception e)
                {
                    if (!File.Exists(path))
                    {
                        File.Create(path);
                        TextWriter tw = new StreamWriter(path, true);
                        tw.WriteLine(DateTime.Now.ToString() + " " + "Url_send:" + " " + url3 + " " + "Error_Message:" + e);
                        tw.Close();
                    }

                    else if (File.Exists(path))
                    {
                        TextWriter tw = new StreamWriter(path, true);
                        tw.WriteLine(DateTime.Now.ToString() + " " + "Url_send:" + " " + url3 + " " + "Error_Message:" + e);
                        tw.Close();
                    }
                }

                driver.Close();
            }
        }

        public void blocageSite(string str, string str1)
        {
            string status = "Bad";
            DateTime date1 = DateTime.Now;
            string date = date1.ToString("MM/dd/yyyy HH:mm");
            try
            {
                // ajouter le site à la base de donnée
                string sql = "insert into parentControl (url, status, date ) values(";
                sql = sql + "'" + str1 + "', ";
                sql = sql + "'" + status + "', ";                
                sql = sql + "'" + date + "')";
                Boolean error = db1.insertData(sourceFile, sql);
                if (error == true)
                {
                    //MessageBox.Show("site Bloqué Par Draka Shiel ");
                    AutoClosingMessageBox.Show("Site Blocked By Draka Shiel ");

                    // ajouter le site au fichier Host : site bloqué
                    using (StreamWriter w = File.AppendText(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "drivers/etc/hosts")))
                    {
                        w.WriteLine(str);
                        w.Close();
                    }
                    MessageBox.Show("Website Blocked");
                }
                else
                {
                    MessageBox.Show("Impossible d'enregistrer le fichier dans la BD");                    
                }
                            
            }
            catch (Exception)
            {
                MessageBox.Show(" cannot block this website \n ");
            }
        }

        public void deblocageSite(String str)
        {
            
            // récupération du contenu du fichier Host.                        
            string[] ContenueHost = File.ReadAllLines(path);
            List<string> Hosts = new List<string>();
            
            StreamWriter st = new StreamWriter(path, false); // j'éfface le contenu du fichier Hosts
            st.Close();
            MessageBox.Show("Contenue du fichier Hosts éffacé");
            foreach (string elt in ContenueHost)
            {
                if(elt.Equals(str))
                {
                    continue;
                }
                else
                {
                    Hosts.Add(elt);
                }
            }
            File.AppendAllLines(path, Hosts);
            //File.WriteAllLines(path, Hosts);
        }

    }

}
