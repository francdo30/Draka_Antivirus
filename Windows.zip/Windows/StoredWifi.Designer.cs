﻿namespace Draka_Antivirus.Windows
{
    partial class StoredWifi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvWifiNetworks = new Guna.UI2.WinForms.Guna2DataGridView();
            this.col_interface = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_ssid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_authentication = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelInfo = new System.Windows.Forms.Label();
            this.btnScan = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWifiNetworks)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvWifiNetworks
            // 
            this.dgvWifiNetworks.AllowUserToAddRows = false;
            this.dgvWifiNetworks.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvWifiNetworks.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvWifiNetworks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvWifiNetworks.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvWifiNetworks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvWifiNetworks.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvWifiNetworks.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvWifiNetworks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvWifiNetworks.ColumnHeadersHeight = 50;
            this.dgvWifiNetworks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_interface,
            this.col_ssid,
            this.col_authentication,
            this.col_password});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvWifiNetworks.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvWifiNetworks.EnableHeadersVisualStyles = false;
            this.dgvWifiNetworks.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvWifiNetworks.Location = new System.Drawing.Point(0, 78);
            this.dgvWifiNetworks.Margin = new System.Windows.Forms.Padding(2);
            this.dgvWifiNetworks.Name = "dgvWifiNetworks";
            this.dgvWifiNetworks.ReadOnly = true;
            this.dgvWifiNetworks.RowHeadersVisible = false;
            this.dgvWifiNetworks.RowHeadersWidth = 51;
            this.dgvWifiNetworks.RowTemplate.Height = 40;
            this.dgvWifiNetworks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvWifiNetworks.Size = new System.Drawing.Size(818, 66);
            this.dgvWifiNetworks.TabIndex = 2;
            this.dgvWifiNetworks.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Alizarin;
            this.dgvWifiNetworks.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvWifiNetworks.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvWifiNetworks.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvWifiNetworks.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvWifiNetworks.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvWifiNetworks.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvWifiNetworks.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.LightGray;
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvWifiNetworks.ThemeStyle.HeaderStyle.Height = 50;
            this.dgvWifiNetworks.ThemeStyle.ReadOnly = true;
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.Height = 40;
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            this.dgvWifiNetworks.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // col_interface
            // 
            this.col_interface.HeaderText = "Interface";
            this.col_interface.MinimumWidth = 6;
            this.col_interface.Name = "col_interface";
            this.col_interface.ReadOnly = true;
            // 
            // col_ssid
            // 
            this.col_ssid.HeaderText = "SSID";
            this.col_ssid.MinimumWidth = 6;
            this.col_ssid.Name = "col_ssid";
            this.col_ssid.ReadOnly = true;
            // 
            // col_authentication
            // 
            this.col_authentication.HeaderText = "Authentication";
            this.col_authentication.MinimumWidth = 6;
            this.col_authentication.Name = "col_authentication";
            this.col_authentication.ReadOnly = true;
            // 
            // col_password
            // 
            this.col_password.HeaderText = "Password";
            this.col_password.MinimumWidth = 6;
            this.col_password.Name = "col_password";
            this.col_password.ReadOnly = true;
            // 
            // labelInfo
            // 
            this.labelInfo.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInfo.Location = new System.Drawing.Point(50, 215);
            this.labelInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(736, 151);
            this.labelInfo.TabIndex = 2;
            this.labelInfo.Text = "Click on Scan to show stored wifi password";
            this.labelInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnScan
            // 
            this.btnScan.Animated = true;
            this.btnScan.BorderRadius = 10;
            this.btnScan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnScan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnScan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnScan.ForeColor = System.Drawing.Color.White;
            this.btnScan.Location = new System.Drawing.Point(684, 11);
            this.btnScan.Margin = new System.Windows.Forms.Padding(2);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(128, 36);
            this.btnScan.TabIndex = 9;
            this.btnScan.Text = "Scan";
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnScan);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(818, 72);
            this.panel1.TabIndex = 0;
            // 
            // StoredWifi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(818, 511);
            this.Controls.Add(this.labelInfo);
            this.Controls.Add(this.dgvWifiNetworks);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "StoredWifi";
            this.Text = "StoredWifi";
            ((System.ComponentModel.ISupportInitialize)(this.dgvWifiNetworks)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2DataGridView dgvWifiNetworks;
        private System.Windows.Forms.Label labelInfo;
        private Guna.UI2.WinForms.Guna2Button btnScan;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_interface;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_ssid;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_authentication;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_password;
    }
}