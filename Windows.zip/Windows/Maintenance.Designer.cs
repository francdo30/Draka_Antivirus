﻿namespace Draka_Antivirus.Windows
{
    partial class Maintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBodyMaintenance = new System.Windows.Forms.Panel();
            this.panelMenuPerfermance = new System.Windows.Forms.Panel();
            this.button4 = new Guna.UI2.WinForms.Guna2Button();
            this.button2 = new Guna.UI2.WinForms.Guna2Button();
            this.button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnRecycle = new Guna.UI2.WinForms.Guna2Button();
            this.panelMenuPerfermance.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBodyMaintenance
            // 
            this.panelBodyMaintenance.AutoScroll = true;
            this.panelBodyMaintenance.BackColor = System.Drawing.Color.White;
            this.panelBodyMaintenance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodyMaintenance.Location = new System.Drawing.Point(192, 0);
            this.panelBodyMaintenance.Margin = new System.Windows.Forms.Padding(4);
            this.panelBodyMaintenance.Name = "panelBodyMaintenance";
            this.panelBodyMaintenance.Size = new System.Drawing.Size(847, 511);
            this.panelBodyMaintenance.TabIndex = 3;
            // 
            // panelMenuPerfermance
            // 
            this.panelMenuPerfermance.AutoScroll = true;
            this.panelMenuPerfermance.BackColor = System.Drawing.Color.White;
            this.panelMenuPerfermance.Controls.Add(this.button4);
            this.panelMenuPerfermance.Controls.Add(this.button2);
            this.panelMenuPerfermance.Controls.Add(this.button1);
            this.panelMenuPerfermance.Controls.Add(this.btnRecycle);
            this.panelMenuPerfermance.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenuPerfermance.Location = new System.Drawing.Point(0, 0);
            this.panelMenuPerfermance.Margin = new System.Windows.Forms.Padding(4);
            this.panelMenuPerfermance.Name = "panelMenuPerfermance";
            this.panelMenuPerfermance.Size = new System.Drawing.Size(192, 511);
            this.panelMenuPerfermance.TabIndex = 2;
            // 
            // button4
            // 
            this.button4.Animated = true;
            this.button4.BorderRadius = 10;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(5, 268);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(182, 56);
            this.button4.TabIndex = 6;
            this.button4.Text = "Mise a jour Windows";
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button2
            // 
            this.button2.Animated = true;
            this.button2.BorderRadius = 10;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(5, 359);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(182, 56);
            this.button2.TabIndex = 7;
            this.button2.Text = "Program at Startup";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Animated = true;
            this.button1.BorderRadius = 10;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(5, 90);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 56);
            this.button1.TabIndex = 3;
            this.button1.Text = "Temporar Items";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnRecycle
            // 
            this.btnRecycle.Animated = true;
            this.btnRecycle.BorderRadius = 10;
            this.btnRecycle.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecycle.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnRecycle.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnRecycle.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRecycle.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnRecycle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnRecycle.ForeColor = System.Drawing.Color.White;
            this.btnRecycle.Location = new System.Drawing.Point(4, 179);
            this.btnRecycle.Margin = new System.Windows.Forms.Padding(2);
            this.btnRecycle.Name = "btnRecycle";
            this.btnRecycle.Size = new System.Drawing.Size(182, 56);
            this.btnRecycle.TabIndex = 4;
            this.btnRecycle.Text = "Basket";
            this.btnRecycle.Click += new System.EventHandler(this.btnRecycle_Click);
            // 
            // Maintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 511);
            this.Controls.Add(this.panelBodyMaintenance);
            this.Controls.Add(this.panelMenuPerfermance);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Maintenance";
            this.Text = "Maintenance";
            this.panelMenuPerfermance.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBodyMaintenance;
        private System.Windows.Forms.Panel panelMenuPerfermance;
        private Guna.UI2.WinForms.Guna2Button btnRecycle;
        private Guna.UI2.WinForms.Guna2Button button1;
        private Guna.UI2.WinForms.Guna2Button button4;
        private Guna.UI2.WinForms.Guna2Button button2;
    }
}