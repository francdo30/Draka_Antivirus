﻿using Draka_Antivirus.DAO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class ObjectionableWebsites : Form
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "objectionable_websites.db";
        public static string sourceFile = targetPath + name_db;
        Database db = new Database();

        public ObjectionableWebsites()
        {
            InitializeComponent();
            if (!File.Exists(sourceFile))
            {
                db.createDatabase(name_db);
            }
        }

        public void enable_controle(Boolean f)
        {

        }


        public Boolean isURL(string url)
        {
            //création d'une uri a valeur "null"
            Uri CreatedUri;

            //on tente de créer l'url en vérifiant qu'elle est conforme a une url http ou https
            Boolean IsValid = Uri.TryCreate(url, UriKind.Absolute, out CreatedUri) && (CreatedUri.Scheme == Uri.UriSchemeHttp || CreatedUri.Scheme == Uri.UriSchemeHttps);

            if ((url != "") && (IsValid))
            {
                return true;// on valide l'url entrée 
            }
            else
            {
                return false;//on invalide l'url entrée
            }
        }

        public void refreshData()
        {
            List<Object[]> datas = db.selectDatasAuto(sourceFile, "select * from objectionable_websites.db");
            dataGridView1.Rows.Clear();

            if (datas != null)
            {
                for (var i = 0; i < datas.Count; i++)
                {
                    dataGridView1.Rows.Add(datas[i]);
                }
            }
        }

        private void ObjectionableWebsites_Load(object sender, EventArgs e)
        {
            refreshData();
        }




        private void btnNew_Click(object sender, EventArgs e)
        {
            enable_controle(true);
        }




        private void btnDelete_Click(object sender, EventArgs e)
        {
            enable_controle(false);

            if (dataGridView1.SelectedRows.Count > 0)
            {
                string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                string url = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                string status = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                string sql = "delete from websites where url='" + url + "'";
                Boolean error = db.deleteData(sourceFile, sql);

                if (error == true)
                {
                    refreshData();
                }
                else
                {
                    MessageBox.Show("Database does not exist", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("No line selected", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        
    }
}
