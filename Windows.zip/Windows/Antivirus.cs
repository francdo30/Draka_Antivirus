﻿using System;
using System.Management;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Antivirus : Form
    {
        public Antivirus()
        {
            InitializeComponent();
            bool returnCode = AntivirusInstalled();
            Console.WriteLine("Antivirus Installed " + returnCode.ToString());
            //MessageBox.Show("Antivirus Installed " + returnCode.ToString());
            Console.WriteLine();
            //Console.Read();
        }
        public bool AntivirusInstalled()
        {

            string wmipathstr = @"\\" + Environment.MachineName + @"\root\SecurityCenter2";
            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher(wmipathstr, "SELECT * FROM AntivirusProduct");
                ManagementObjectCollection instances = searcher.Get();
                dgvVirus.Rows.Clear();
                foreach (ManagementObject queryObj in searcher.Get())
                {
                    String state = queryObj["productState"].ToString();
                    switch (state)
                    {
                        case "397568"://Windows defender
                            state = "Enabled and up to date";
                            break;
                        case "397584"://Windows defender
                            state = "Enabled and out to date";
                            break;
                        case "393472"://Windows defender
                            state = "Disabled and up to date";
                            break;
                        case "397312"://Microsoft security essentials
                            state = "Enabled and up to date";
                            break;
                        case "393216"://Microsoft security essentials
                            state = "Disabled and up to date";
                            break;
                        case "266256"://AVG Internet Security 2012 firewall product
                            state = "Firewall enabled";
                            break;
                        case "262160"://AVG Internet Security 2012 firewall product
                            state = "Firewall disabled";
                            break;
                        case "262144"://AVG Internet Security 2012 antivirus product
                            state = "Disable and up to date";
                            break;
                        case "266240"://AVG Internet Security 2012 antivirus product
                            state = "Enabled and up to date";
                            break;
                        default://We don't have information about product
                            state = queryObj["productState"].ToString();
                            break;
                    }
                    dgvVirus.Rows.Add(new Object[] { queryObj["displayName"], queryObj["instanceGuid"], queryObj["pathToSignedProductExe"], /*queryObj["productState"]*/ state });
                    Console.WriteLine("-----------------------------------");
                    Console.WriteLine("InstanceName: {0}", queryObj.ToString());


                }
                return instances.Count > 0;
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                MessageBox.Show(e.Message);
            }

            return false;
        }

        private void dgvVirus_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
