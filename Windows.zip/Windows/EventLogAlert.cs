﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class EventLogAlert : Form
    {
        public EventLogAlert()
        {
            InitializeComponent();
            GetSystemLogs();
            GetSecurityLogs();
            GetApplicationLogs();
        }

        public void GetSystemLogs()
        {
            if (!EventLog.Exists("System", Environment.MachineName))
            {
                labelSystemCount.Text = "0";
                return;
            }
            else
            {
                EventLog myLog = new EventLog("System", Environment.MachineName);
                labelSystemCount.Text = myLog.Entries.Count.ToString();
            }
        }
        public void GetSecurityLogs()
        {
            try
            {
                if (!EventLog.Exists("Security", Environment.MachineName))
                {
                    labelSecurityCount.Text = "0";
                    return;
                }
                else
                {
                    EventLog myLog = new EventLog("Security", Environment.MachineName);
                    labelSecurityCount.Text = myLog.Entries.Count.ToString();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        public void GetApplicationLogs()
        {
            if (!EventLog.Exists("Application", Environment.MachineName))
            {
                labelAppCount.Text = "0";
                return;
            }
            else
            {
                EventLog myLog = new EventLog("Application", Environment.MachineName);
                labelAppCount.Text = myLog.Entries.Count.ToString();
            }
        }

        private void EventLogAlert_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.FullRowSelect = true;

            EventLog[] remoteEventLogs;

            remoteEventLogs = EventLog.GetEventLogs();
            /*remoteEventLogs = EventLog.;*/

            Console.WriteLine("Number of logs on computer: " + remoteEventLogs.Length);

            foreach (EventLog log in remoteEventLogs)
            {
                Console.WriteLine("Log: " + log.Log);
                listView1.Items.Add(new ListViewItem(new string[] { log.Log, log.OverflowAction.ToString(), log.Entries.Count.ToString() }));
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
