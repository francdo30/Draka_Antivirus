﻿using System;
using System.Management;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class RestorePoints : Form
    {
        public const string SYSTEM_RESTORE = "SystemRestore";
        public const string CREATE_SYSTEM_RESTORE_POINT = "CreateRestorePoint";
        public const string SYSTEM_RESTORE_POINT_DESCRIPTION = "Description";
        public const string SYSTEM_RESTORE_POINT_TYPE = "RestorePointType";
        public const string SYSTEM_RESTORE_EVENTTYPE = "EventType";

        public RestorePoints()
        {
            InitializeComponent();
            getRestorePoint();
        }

        //Get all restore point
        public void getRestorePoint()
        {
            listView1.View = View.Details;

            ManagementClass c = new ManagementClass("root/default:SystemRestore");
            Console.WriteLine(c.ToString());
            try
            {
                foreach (ManagementObject o in c.GetInstances())
                {
                    listView1.Items.Add(new ListViewItem(new string[] { o["Description"].ToString(), o["RestorePointType"].ToString(), o["EventType"].ToString(), o["SequenceNumber"].ToString(), getDate(o["CreationTime"].ToString()) }));
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message.ToString());
            }

        }

        public String getDate(String d)
        {
            String date = d.Remove(4);
            d = d.Remove(0, 4);
            date += "/" + d.Remove(2);
            d = d.Remove(0, 2);
            date += "/" + d.Remove(2);
            d = d.Remove(0, 2);
            date += " " + d.Remove(2);
            d = d.Remove(0, 2);
            date += ":" + d.Remove(2);
            d = d.Remove(0, 2);
            date += ":" + d.Remove(2);
            return date;
        }

        //Create restore point
        public static bool CreateRestorePoint()
        {
            bool isCreated = true;
            try
            {
                ManagementClass mcProcess = new ManagementClass
                (
                     new ManagementScope("\\\\localhost\\root\\default"),
                     new ManagementPath(SYSTEM_RESTORE),
                     new ObjectGetOptions()
                );

                ManagementBaseObject mbObjectInput = mcProcess.GetMethodParameters(CREATE_SYSTEM_RESTORE_POINT);
                mbObjectInput[SYSTEM_RESTORE_POINT_DESCRIPTION] = string.Format("Restore point created on : " + DateTime.Now.ToString());
                mbObjectInput[SYSTEM_RESTORE_POINT_TYPE] = 0;
                mbObjectInput[SYSTEM_RESTORE_EVENTTYPE] = 100;

                ManagementBaseObject mbObjectOutput = mcProcess.InvokeMethod(CREATE_SYSTEM_RESTORE_POINT, mbObjectInput, null);

                isCreated = (mbObjectInput == null) ? !isCreated : isCreated;
            }
            catch (ManagementException me)
            {
                //handle the error.
                Console.WriteLine(me.ToString());
                isCreated = !isCreated;
            }


            return isCreated;
        }


        // Delete restore Point
        [DllImport("Srclient.dll")]
        public static extern int SRRemoveRestorePoint(int index);
        public static int DeleteRestorePoint(int SequenceNumber)
        {
            int intReturn = SRRemoveRestorePoint(SequenceNumber);
            return intReturn;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                listView1.Visible = false;
                pictureBox1.Visible = true;
                label3.Visible = true;
                label4.Visible = false;
                bool iscreated1 = false;
                if (iscreated1 != CreateRestorePoint())
                {
                    AutoClosingMessageBox.Show("Point de restauration creer le : " + DateTime.Now.ToString(), "Point de Restauration", 10000);
                    getRestorePoint();
                    listView1.Visible = true;
                    pictureBox1.Visible = false;
                    label3.Visible = false;
                    label4.Visible = false;
                }
                else
                {
                    listView1.Visible = false;
                    pictureBox1.Visible = true;
                    label3.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string Sequence = listView1.SelectedItems[0].SubItems[3].Text;
                int SequenceNum = int.Parse(Sequence);
                var number = DeleteRestorePoint(SequenceNum);
                pictureBox1.Visible = false;
                label3.Visible = false;
                label4.Visible = false;

                Console.WriteLine(number);
                if (number == 0)
                {
                    AutoClosingMessageBox.Show("Point supprimer avec succes", "Point de Restauration", 10000);
                    listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
                    this.getRestorePoint();
                }
                else
                {
                    AutoClosingMessageBox.Show("Erreur Impossible de supprimer le Point de restoration", "Point de Restauration", 10000);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void RestorePoints_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
        }
    }
}
