﻿namespace Draka_Antivirus.Windows
{
    partial class Securite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnFirewall = new Guna.UI2.WinForms.Guna2Button();
            this.btnAntivirus = new Guna.UI2.WinForms.Guna2Button();
            this.btnStoredWifi = new Guna.UI2.WinForms.Guna2Button();
            this.btnObjectionableWeb = new Guna.UI2.WinForms.Guna2Button();
            this.roundedButton1 = new Guna.UI2.WinForms.Guna2Button();
            this.panelBodySecurity = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnFirewall);
            this.panel1.Controls.Add(this.btnAntivirus);
            this.panel1.Controls.Add(this.btnStoredWifi);
            this.panel1.Controls.Add(this.btnObjectionableWeb);
            this.panel1.Controls.Add(this.roundedButton1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(203, 511);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Animated = true;
            this.button1.BorderRadius = 10;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(7, 267);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 57);
            this.button1.TabIndex = 7;
            this.button1.Text = "Parental Control";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnFirewall
            // 
            this.btnFirewall.Animated = true;
            this.btnFirewall.BorderRadius = 10;
            this.btnFirewall.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFirewall.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnFirewall.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnFirewall.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnFirewall.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnFirewall.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnFirewall.ForeColor = System.Drawing.Color.White;
            this.btnFirewall.Location = new System.Drawing.Point(7, 15);
            this.btnFirewall.Margin = new System.Windows.Forms.Padding(2);
            this.btnFirewall.Name = "btnFirewall";
            this.btnFirewall.Size = new System.Drawing.Size(182, 57);
            this.btnFirewall.TabIndex = 3;
            this.btnFirewall.Text = "Firewall";
            this.btnFirewall.Click += new System.EventHandler(this.btnFirewall_Click);
            // 
            // btnAntivirus
            // 
            this.btnAntivirus.Animated = true;
            this.btnAntivirus.BorderRadius = 10;
            this.btnAntivirus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAntivirus.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAntivirus.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAntivirus.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAntivirus.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAntivirus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnAntivirus.ForeColor = System.Drawing.Color.White;
            this.btnAntivirus.Location = new System.Drawing.Point(7, 95);
            this.btnAntivirus.Margin = new System.Windows.Forms.Padding(2);
            this.btnAntivirus.Name = "btnAntivirus";
            this.btnAntivirus.Size = new System.Drawing.Size(182, 57);
            this.btnAntivirus.TabIndex = 6;
            this.btnAntivirus.Text = "Antivirus";
            this.btnAntivirus.Click += new System.EventHandler(this.btnAntivirus_Click);
            // 
            // btnStoredWifi
            // 
            this.btnStoredWifi.Animated = true;
            this.btnStoredWifi.BorderRadius = 10;
            this.btnStoredWifi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStoredWifi.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnStoredWifi.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnStoredWifi.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnStoredWifi.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnStoredWifi.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnStoredWifi.ForeColor = System.Drawing.Color.White;
            this.btnStoredWifi.Location = new System.Drawing.Point(7, 353);
            this.btnStoredWifi.Margin = new System.Windows.Forms.Padding(2);
            this.btnStoredWifi.Name = "btnStoredWifi";
            this.btnStoredWifi.Size = new System.Drawing.Size(182, 57);
            this.btnStoredWifi.TabIndex = 6;
            this.btnStoredWifi.Text = "Wifi pass word";
            this.btnStoredWifi.Click += new System.EventHandler(this.btnStoredWifi_Click);
            // 
            // btnObjectionableWeb
            // 
            this.btnObjectionableWeb.Animated = true;
            this.btnObjectionableWeb.BorderRadius = 10;
            this.btnObjectionableWeb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnObjectionableWeb.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnObjectionableWeb.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnObjectionableWeb.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnObjectionableWeb.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnObjectionableWeb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnObjectionableWeb.ForeColor = System.Drawing.Color.White;
            this.btnObjectionableWeb.Location = new System.Drawing.Point(7, 436);
            this.btnObjectionableWeb.Margin = new System.Windows.Forms.Padding(2);
            this.btnObjectionableWeb.Name = "btnObjectionableWeb";
            this.btnObjectionableWeb.Size = new System.Drawing.Size(182, 57);
            this.btnObjectionableWeb.TabIndex = 6;
            this.btnObjectionableWeb.Text = "Objectionable websites";
            this.btnObjectionableWeb.Click += new System.EventHandler(this.btnObjectionableWeb_Click);
            // 
            // roundedButton1
            // 
            this.roundedButton1.Animated = true;
            this.roundedButton1.BorderRadius = 10;
            this.roundedButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.roundedButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.roundedButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.roundedButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.roundedButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.roundedButton1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.roundedButton1.ForeColor = System.Drawing.Color.White;
            this.roundedButton1.Location = new System.Drawing.Point(7, 178);
            this.roundedButton1.Margin = new System.Windows.Forms.Padding(2);
            this.roundedButton1.Name = "roundedButton1";
            this.roundedButton1.Size = new System.Drawing.Size(182, 57);
            this.roundedButton1.TabIndex = 6;
            this.roundedButton1.Text = "password save";
            this.roundedButton1.Click += new System.EventHandler(this.roundedButton1_Click);
            // 
            // panelBodySecurity
            // 
            this.panelBodySecurity.AutoScroll = true;
            this.panelBodySecurity.BackColor = System.Drawing.Color.White;
            this.panelBodySecurity.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodySecurity.Location = new System.Drawing.Point(203, 0);
            this.panelBodySecurity.Margin = new System.Windows.Forms.Padding(4);
            this.panelBodySecurity.Name = "panelBodySecurity";
            this.panelBodySecurity.Size = new System.Drawing.Size(836, 511);
            this.panelBodySecurity.TabIndex = 2;
            // 
            // Securite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 511);
            this.Controls.Add(this.panelBodySecurity);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Securite";
            this.Text = "Securite";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }


        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelBodySecurity;
        private Guna.UI2.WinForms.Guna2Button btnStoredWifi;
        private Guna.UI2.WinForms.Guna2Button button1;
        private Guna.UI2.WinForms.Guna2Button btnObjectionableWeb;
        private Guna.UI2.WinForms.Guna2Button btnFirewall;
        private Guna.UI2.WinForms.Guna2Button btnAntivirus;
        private Guna.UI2.WinForms.Guna2Button roundedButton1;
    }
}