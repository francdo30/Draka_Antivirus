﻿using System;
using System.Windows.Forms;
/*using WUApiLib;*/

namespace Draka_Antivirus.Windows
{
    public partial class Update : Form
    {
        public Update()
        {
            InitializeComponent();

            label8.Visible = false;
            label9.Visible = false;
            label7.Visible = false;
            label10.Visible = false;

            // Windows Update Begin
            /*
                        var AUC = new AutomaticUpdatesClass();
                        bool isWUEnabled = AUC.ServiceEnabled;

                        if (isWUEnabled)
                        {
                            //Console.WriteLine("Windows Update is Enabled");
                            label2.Text = "Enabled";
                        }
                        else
                        {
                            //Console.WriteLine("Windows Update is Disabled");
                            label2.Text = "Disabled";
                        }



                        DateTime? lastInstallationSuccessDateUtc = null;
                        if (AUC.Results.LastInstallationSuccessDate is DateTime)
                        {
                            lastInstallationSuccessDateUtc = new DateTime(((DateTime)AUC.Results.LastInstallationSuccessDate).Ticks, DateTimeKind.Utc);
                            label5.Text = lastInstallationSuccessDateUtc.ToString();
                        }

                        DateTime? lastSearchSuccessDateUtc = null;
                        if (AUC.Results.LastSearchSuccessDate is DateTime)
                        {
                            lastSearchSuccessDateUtc = new DateTime(((DateTime)AUC.Results.LastSearchSuccessDate).Ticks, DateTimeKind.Utc);
                            label3.Text = lastSearchSuccessDateUtc.ToString();
                        }

                        // End Windows update 
                    }

                    private void GetSystemUpdate()
                    {
                        listView1.View = View.Details;
                        label2.Visible = false;
                        label3.Visible = false;
                        label5.Visible = false;
                        label8.Visible = false;
                        label9.Visible = false;
                        label7.Visible = false;
                        label10.Visible = false;
                        // Now, we need to search the Microsoft updates
                        UpdateSessionClass uSession = new UpdateSessionClass();
                        IUpdateSearcher uSearcher = uSession.CreateUpdateSearcher();
                        ISearchResult uResult = uSearcher.Search("IsInstalled=0 and Type = 'Software'"); 
                        foreach (IUpdate update in uResult.Updates)
                        {
                            Console.WriteLine(update.Title);
                        }

                        //Now we have to create an UpdateDownloader class object to download the updates
                        UpdateDownloader downloader = uSession.CreateUpdateDownloader();
                        downloader.Updates = uResult.Updates;
                        downloader.Download();

                        //Now, as we have completed the download of the required updates, we have to install the
                        //downloaded updates by checking its IsDownloaded property is true.
                        int i = 0;
                        int size = 0;
                        UpdateCollection updatesToInstall = new UpdateCollection();
                        foreach (IUpdate update in uResult.Updates)
                        {
                            if (update.IsDownloaded)
                                updatesToInstall.Add(update);
                            i++;
                            size = size + (int)update.MaxDownloadSize;
                            if (listView1.Items.Count == 0)
                            {
                                listView1.Visible = false;
                                pictureBox1.Visible = true;
                            }
                            else
                            {
                                listView1.Items.Add(new ListViewItem(new string[] { update.Title, update.MaxDownloadSize.ToString() + " KB" }));
                            }

                        }
                        label8.Visible = true;
                        label9.Visible = true;
                        label7.Visible = true;
                        label10.Visible = true;

                        label8.Text = i.ToString();
                        label9.Text = size.ToString() + " KB";
                        //Now assign the update collection of to be installed updates to the installer class
                        IUpdateInstaller installer = uSession.CreateUpdateInstaller();
                        installer.Updates = updatesToInstall;

                        //Now, call the install method of the IUpdateInstaller object and result of which will be stored in
                        //IInstallationResult object installationRes.
                        IInstallationResult installationRes = installer.Install();

                        //Now as all updates will be installed sequentally by the WUAPI
                        int k = 0, l = 0;
                        for (int i1 = 0; i1 < updatesToInstall.Count; i1++)
                        {
                            if (installationRes.GetUpdateResult(i1).HResult == 0)
                            {
                                Console.WriteLine("Installed : " + updatesToInstall[i1].Title);
                                k++;
                            }
                            else
                            {
                                Console.WriteLine("Failed : " + updatesToInstall[i1].Title);
                                l++;
                            }
                        }

                        AutoClosingMessageBox.Show("Draka Antivirus a Intaller : " + k + " Mise a jour et : " + l + " Ne sont pas installer", "Update", 10000);
                        label2.Visible = true;
                        label3.Visible = true;
                        label5.Visible = true;

                        var AUC = new AutomaticUpdatesClass();
                        bool isWUEnabled = AUC.ServiceEnabled;
                        if (isWUEnabled)
                        {
                            //Console.WriteLine("Windows Update is Enabled");
                            label2.Text = "Enabled";
                        }
                        else
                        {
                            //Console.WriteLine("Windows Update is Disabled");
                            label2.Text = "Disabled";
                        }



                        DateTime? lastInstallationSuccessDateUtc = null;
                        if (AUC.Results.LastInstallationSuccessDate is DateTime)
                        {
                            lastInstallationSuccessDateUtc = new DateTime(((DateTime)AUC.Results.LastInstallationSuccessDate).Ticks, DateTimeKind.Utc);
                            label5.Text = lastInstallationSuccessDateUtc.ToString();
                        }

                        DateTime? lastSearchSuccessDateUtc = null;
                        if (AUC.Results.LastSearchSuccessDate is DateTime)
                        {
                            lastSearchSuccessDateUtc = new DateTime(((DateTime)AUC.Results.LastSearchSuccessDate).Ticks, DateTimeKind.Utc);
                            label3.Text = lastSearchSuccessDateUtc.ToString();
                        }
                    }
                    private void label1_Click(object sender, EventArgs e)
                    {

                    }

                    private void button1_Click(object sender, EventArgs e)
                    {
                        listView1.Clear();
                        GetSystemUpdate();
                    }

                    private void WindowsUpdate_Load(object sender, EventArgs e)
                    {

                    }  */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Clear();
            /*GetSystemUpdate();*/

        }
    }
}
