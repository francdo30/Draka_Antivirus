﻿namespace Draka_Antivirus.Windows
{
    partial class BankCards
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgvBankcards = new Guna.UI2.WinForms.Guna2DataGridView();
            this.col_url = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_user = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_browser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnScan = new Guna.UI2.WinForms.Guna2Button();
            this.LBL_COUNT_BANKCARDS = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBankcards)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvBankcards
            // 
            this.dgvBankcards.AllowUserToAddRows = false;
            this.dgvBankcards.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvBankcards.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvBankcards.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBankcards.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvBankcards.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvBankcards.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvBankcards.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBankcards.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvBankcards.ColumnHeadersHeight = 65;
            this.dgvBankcards.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_url,
            this.col_user,
            this.col_password,
            this.col_browser});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBankcards.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvBankcards.EnableHeadersVisualStyles = false;
            this.dgvBankcards.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBankcards.Location = new System.Drawing.Point(0, 93);
            this.dgvBankcards.Margin = new System.Windows.Forms.Padding(2);
            this.dgvBankcards.Name = "dgvBankcards";
            this.dgvBankcards.ReadOnly = true;
            this.dgvBankcards.RowHeadersVisible = false;
            this.dgvBankcards.RowHeadersWidth = 51;
            this.dgvBankcards.RowTemplate.Height = 65;
            this.dgvBankcards.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBankcards.Size = new System.Drawing.Size(808, 66);
            this.dgvBankcards.TabIndex = 2;
            this.dgvBankcards.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Alizarin;
            this.dgvBankcards.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvBankcards.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvBankcards.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvBankcards.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvBankcards.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvBankcards.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvBankcards.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvBankcards.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.LightGray;
            this.dgvBankcards.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvBankcards.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dgvBankcards.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvBankcards.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvBankcards.ThemeStyle.HeaderStyle.Height = 65;
            this.dgvBankcards.ThemeStyle.ReadOnly = true;
            this.dgvBankcards.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            this.dgvBankcards.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvBankcards.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvBankcards.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvBankcards.ThemeStyle.RowsStyle.Height = 65;
            this.dgvBankcards.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            this.dgvBankcards.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // col_url
            // 
            this.col_url.HeaderText = "Bank card Name";
            this.col_url.MinimumWidth = 6;
            this.col_url.Name = "col_url";
            this.col_url.ReadOnly = true;
            // 
            // col_user
            // 
            this.col_user.HeaderText = "Bank card Number";
            this.col_user.MinimumWidth = 6;
            this.col_user.Name = "col_user";
            this.col_user.ReadOnly = true;
            // 
            // col_password
            // 
            this.col_password.FillWeight = 50F;
            this.col_password.HeaderText = "Status";
            this.col_password.MinimumWidth = 6;
            this.col_password.Name = "col_password";
            this.col_password.ReadOnly = true;
            // 
            // col_browser
            // 
            this.col_browser.FillWeight = 40F;
            this.col_browser.HeaderText = "Browser";
            this.col_browser.MinimumWidth = 6;
            this.col_browser.Name = "col_browser";
            this.col_browser.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnScan);
            this.panel1.Controls.Add(this.LBL_COUNT_BANKCARDS);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(808, 84);
            this.panel1.TabIndex = 3;
            // 
            // btnScan
            // 
            this.btnScan.Animated = true;
            this.btnScan.BorderRadius = 10;
            this.btnScan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnScan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnScan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnScan.ForeColor = System.Drawing.Color.White;
            this.btnScan.Location = new System.Drawing.Point(809, 27);
            this.btnScan.Margin = new System.Windows.Forms.Padding(2);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(146, 36);
            this.btnScan.TabIndex = 9;
            this.btnScan.Text = "Scan";
            // 
            // LBL_COUNT_BANKCARDS
            // 
            this.LBL_COUNT_BANKCARDS.AutoSize = true;
            this.LBL_COUNT_BANKCARDS.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_COUNT_BANKCARDS.Location = new System.Drawing.Point(303, 27);
            this.LBL_COUNT_BANKCARDS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LBL_COUNT_BANKCARDS.Name = "LBL_COUNT_BANKCARDS";
            this.LBL_COUNT_BANKCARDS.Size = new System.Drawing.Size(26, 29);
            this.LBL_COUNT_BANKCARDS.TabIndex = 0;
            this.LBL_COUNT_BANKCARDS.Text = "0";
            this.LBL_COUNT_BANKCARDS.Click += new System.EventHandler(this.LBL_COUNT_BANKCARDS_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bank cards and SSN : ";
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(808, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 511);
            this.panel2.TabIndex = 4;
            // 
            // BankCards
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(818, 511);
            this.Controls.Add(this.dgvBankcards);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BankCards";
            this.Text = "BankCards";
            ((System.ComponentModel.ISupportInitialize)(this.dgvBankcards)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        // private System.Windows.Forms.DataGridView dgvBankcards;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LBL_COUNT_BANKCARDS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_url;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_user;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_password;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_browser;
        private Guna.UI2.WinForms.Guna2Button btnScan;
        private Guna.UI2.WinForms.Guna2DataGridView dgvBankcards;
    }
}