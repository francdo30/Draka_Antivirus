﻿using Draka_Antivirus.DAO;
using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Quarantaine : Form
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "ScanDataBase.db";
        public static string sourceFile = targetPath + name_db;
        Database db1 = new Database();

        string path = targetPath + "Error_Log.txt";
        /*string path = @"C:\Program Files (x86)\Default Company Name\Setup1\Error_Log.txt";*/

        // for test
        /*string path = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";*/

        public Quarantaine()
        {
            InitializeComponent();
        }

        private void Quarantaine_Load(object sender, EventArgs e)
        {
            QuarantaineHistoricsloading();
        }

        private void QuarantaineHistoricsloading()
        {
            listView1.View = View.Details;
            string sql2 = "";
            int i1 = 0;
            try
            {
                string sql = "SELECT COUNT(Id) FROM Quarantaine; ";
                var conn = new SQLiteConnection("Data Source=" + sourceFile + ";");
                conn.Open();
                var cmd = new SQLiteCommand(sql, conn);
                Object i = cmd.ExecuteScalar();
                Int64 LastRowID64 = Int64.Parse(i.ToString());
                Console.WriteLine("indice = " + LastRowID64);

                int LastRowID = (int)LastRowID64;
                conn.Close();

                if (LastRowID > 0)
                {
                    pictureBox1.Visible = false;
                    while (i1 <= LastRowID)
                    {
                        sql2 = "select chemin, detection, date from Quarantaine where Id= " + i1 + ";";
                        Object[] dburl = db1.searchData(sourceFile, sql2);

                        if (dburl != null)
                        {
                            listView1.Items.Add(new ListViewItem(new string[] { dburl[0].ToString(), dburl[1].ToString(), dburl[2].ToString() }));
                        }

                        i1++;
                    }
                }
                else
                {
                    pictureBox1.Visible = true;
                    label1.Visible = true;
                    listView1.Visible = false;
                }

            }
            catch (Exception ex)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql2 + " " + "Error_Message:" + ex);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql2 + " " + "Error_Message:" + ex);
                    tw.Close();
                }
            }
        }
        // autres méthodes : Suppression du repertoire quarantaine

        private void DeleteItemToQuarantaine(string chemin)
        {
            string sql = "SELECT nouveldirection FROM Quarantaine where date = '" + chemin + "';";
            //Console.WriteLine("i = " + i);
            try
            {
                Object[] dburl = db1.searchData(sourceFile, sql);
                if (dburl != null)
                {
                    AutoClosingMessageBox.Show("Nouveau chemin trouvé " + dburl);
                    if (FileSystem.FileExists(dburl[0].ToString()))
                    {
                        DialogResult result;
                        result = MessageBox.Show("Voullez-vous supprimer ce fichier de la quarantaine ?", "Quarantaine", MessageBoxButtons.YesNo);
                        if (result == DialogResult)
                            FileSystem.DeleteFile(dburl[0].ToString());
                        db1.deleteData(sourceFile, sql);
                        AutoClosingMessageBox.Show("suppression réussi ");

                    }
                    else
                    {
                        MessageBox.Show("Le fichier n'existe pas en Quarantaine ");
                    }

                }

            }
            catch (Exception ex)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }
            }
        }

        // autres méthodes : Restauration du repertoire quarantaine

        private void RestoreItemToQuarantaine(string chemin)
        {
            string sql = "SELECT nouveldirection FROM Quarantaine where date = '" + chemin + "';";
            try
            {
                Object[] dburl = db1.searchData(sourceFile, sql);
                if (dburl != null)
                {
                    if (FileSystem.FileExists(dburl[0].ToString()))
                    {
                        DialogResult result;
                        result = MessageBox.Show("Voullez-vous restorer ce fichier ?", "Quarantaine", MessageBoxButtons.YesNo);
                        if (result == DialogResult)
                            FileSystem.MoveFile(dburl[0].ToString(), chemin, true);

                    }
                    else
                    {
                        MessageBox.Show("Le fichier n'existe pas en Quarantaine ");
                    }

                }

            }
            catch (Exception ex)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }
            }
        }

        // autres méthodes : Elements de la quarantaine sur 

        private void SureItemToQuarantaine(string chemin)
        {
            string sql = "SELECT nouveldirection FROM Quarantaine where date = '" + chemin + "';";
            try
            {
                Object[] dburl = db1.searchData(sourceFile, sql);
                if (dburl != null)
                {
                    if (FileSystem.FileExists(dburl[0].ToString()))
                    {
                        DialogResult result;
                        result = MessageBox.Show("Voullez-vous rendre ce fichier sur ?", "Quarantaine", MessageBoxButtons.YesNo);
                        if (result == DialogResult)
                            FileSystem.CopyFile(dburl[0].ToString(), chemin, true);

                    }
                    else
                    {
                        MessageBox.Show("Le fichier n'existe pas en Quarantaine ");
                    }

                }

            }
            catch (Exception ex)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + sql + " " + "Error_Message:" + ex);
                    tw.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listView1.Visible == false)
            {
                MessageBox.Show("Aucun element en Quarantaine");
            }
            else
            {
                ListView.SelectedListViewItemCollection selectedElement = this.listView1.SelectedItems;
                foreach (ListViewItem item in selectedElement)
                {
                    RestoreItemToQuarantaine(item.SubItems[0].Text);
                    AutoClosingMessageBox.Show("Méthode restore appelé" + item.SubItems[0].Text);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listView1.Visible == false)
            {
                MessageBox.Show("Aucun element en Quarantaine");
            }
            else
            {
                ListView.SelectedListViewItemCollection selectedElement = this.listView1.SelectedItems;
                foreach (ListViewItem item in selectedElement)
                {
                    string sql = "SELECT nouveldirection FROM Quarantaine where date = '" + item + "';";
                    DeleteItemToQuarantaine(item.SubItems[0].Text);
                    AutoClosingMessageBox.Show("\n" + item);
                    Boolean value = db1.deleteData(Quarantaine.sourceFile, sql);
                    Console.WriteLine("la valeur de value = " + value);
                    item.Remove();
                    if (value == true)
                    {
                        AutoClosingMessageBox.Show("table quarantaine vidé ");
                    }
                    else
                    {
                        AutoClosingMessageBox.Show("impossible de vider la table quarantaine ");
                    }
                    AutoClosingMessageBox.Show("Méthode delete appelé");
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.Visible == false)
            {
                AutoClosingMessageBox.Show("Aucun element en Quarantaine");
            }
            else
            {
                ListView.SelectedListViewItemCollection selectedElement = this.listView1.SelectedItems;
                foreach (ListViewItem item in selectedElement)
                {
                    SureItemToQuarantaine(item.SubItems[0].Text);
                    AutoClosingMessageBox.Show("élément sure en quanrantaire");
                }
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (listView1.Visible == false)
            {
                AutoClosingMessageBox.Show("Aucun element en Quarantaine");
            }
            else
            {
                foreach (ListViewItem item in listView1.Items)
                {
                    item.Selected = true;
                    item.BackColor = Color.Blue;
                }
            }

        }
    }
}
