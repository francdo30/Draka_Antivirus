﻿using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    partial class StoredPwd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnScan = new Guna.UI2.WinForms.Guna2Button();
            this.LBL_COUNT_STORED = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvStoredPassword = new Guna.UI2.WinForms.Guna2DataGridView();
            this.col_url = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_user = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.col_browser = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStoredPassword)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.btnScan);
            this.panel1.Controls.Add(this.LBL_COUNT_STORED);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(818, 90);
            this.panel1.TabIndex = 0;
            // 
            // btnScan
            // 
            this.btnScan.Animated = true;
            this.btnScan.BorderRadius = 10;
            this.btnScan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnScan.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnScan.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnScan.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnScan.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnScan.ForeColor = System.Drawing.Color.White;
            this.btnScan.Location = new System.Drawing.Point(626, 26);
            this.btnScan.Margin = new System.Windows.Forms.Padding(2);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(151, 36);
            this.btnScan.TabIndex = 9;
            this.btnScan.Text = "Scan";
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // LBL_COUNT_STORED
            // 
            this.LBL_COUNT_STORED.AutoSize = true;
            this.LBL_COUNT_STORED.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_COUNT_STORED.ForeColor = System.Drawing.Color.Black;
            this.LBL_COUNT_STORED.Location = new System.Drawing.Point(211, 31);
            this.LBL_COUNT_STORED.Name = "LBL_COUNT_STORED";
            this.LBL_COUNT_STORED.Size = new System.Drawing.Size(17, 19);
            this.LBL_COUNT_STORED.TabIndex = 26;
            this.LBL_COUNT_STORED.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft JhengHei UI Light", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(14, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(183, 24);
            this.label1.TabIndex = 23;
            this.label1.Text = "Stored password :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(808, 90);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 421);
            this.panel2.TabIndex = 1;
            // 
            // dgvStoredPassword
            // 
            this.dgvStoredPassword.AllowUserToAddRows = false;
            this.dgvStoredPassword.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvStoredPassword.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvStoredPassword.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStoredPassword.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvStoredPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvStoredPassword.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvStoredPassword.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvStoredPassword.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvStoredPassword.ColumnHeadersHeight = 50;
            this.dgvStoredPassword.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.col_url,
            this.col_user,
            this.col_password,
            this.col_browser});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStoredPassword.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvStoredPassword.EnableHeadersVisualStyles = false;
            this.dgvStoredPassword.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvStoredPassword.Location = new System.Drawing.Point(0, 96);
            this.dgvStoredPassword.Margin = new System.Windows.Forms.Padding(2);
            this.dgvStoredPassword.Name = "dgvStoredPassword";
            this.dgvStoredPassword.ReadOnly = true;
            this.dgvStoredPassword.RowHeadersVisible = false;
            this.dgvStoredPassword.RowHeadersWidth = 51;
            this.dgvStoredPassword.RowTemplate.Height = 40;
            this.dgvStoredPassword.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStoredPassword.Size = new System.Drawing.Size(807, 406);
            this.dgvStoredPassword.TabIndex = 2;
            this.dgvStoredPassword.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Alizarin;
            this.dgvStoredPassword.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(201)))), ((int)(((byte)(197)))));
            this.dgvStoredPassword.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.dgvStoredPassword.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.dgvStoredPassword.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.dgvStoredPassword.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.dgvStoredPassword.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.dgvStoredPassword.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.LightGray;
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.dgvStoredPassword.ThemeStyle.HeaderStyle.Height = 50;
            this.dgvStoredPassword.ThemeStyle.ReadOnly = true;
            this.dgvStoredPassword.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(219)))), ((int)(((byte)(216)))));
            this.dgvStoredPassword.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvStoredPassword.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.dgvStoredPassword.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvStoredPassword.ThemeStyle.RowsStyle.Height = 40;
            this.dgvStoredPassword.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(135)))), ((int)(((byte)(125)))));
            this.dgvStoredPassword.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // col_url
            // 
            this.col_url.DataPropertyName = "url";
            this.col_url.HeaderText = "Url";
            this.col_url.MinimumWidth = 6;
            this.col_url.Name = "col_url";
            this.col_url.ReadOnly = true;
            // 
            // col_user
            // 
            this.col_user.HeaderText = "User Name";
            this.col_user.MinimumWidth = 6;
            this.col_user.Name = "col_user";
            this.col_user.ReadOnly = true;
            // 
            // col_password
            // 
            this.col_password.DataPropertyName = "pwds";
            this.col_password.HeaderText = "Password";
            this.col_password.MinimumWidth = 6;
            this.col_password.Name = "col_password";
            this.col_password.ReadOnly = true;
            // 
            // col_browser
            // 
            this.col_browser.HeaderText = "Browser";
            this.col_browser.MinimumWidth = 6;
            this.col_browser.Name = "col_browser";
            this.col_browser.ReadOnly = true;
            // 
            // StoredPwd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(818, 511);
            this.Controls.Add(this.dgvStoredPassword);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "StoredPwd";
            this.Text = "StoredPwd";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStoredPassword)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2DataGridView dgvStoredPassword;
        private System.Windows.Forms.Label LBL_COUNT_STORED;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_url;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_user;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_password;
        private System.Windows.Forms.DataGridViewTextBoxColumn col_browser;
        private Guna.UI2.WinForms.Guna2Button btnScan;
    }
}