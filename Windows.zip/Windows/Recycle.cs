﻿using Microsoft.Graph;
using Microsoft.VisualBasic.FileIO;
//using Shell32; 
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
/*using Xamarin.Forms;*/
using ListView = System.Windows.Forms.ListView;
using View = System.Windows.Forms.View;
/*using System.Management.Automation;
using System.Management.Automation.Runspaces;*/

namespace Draka_Antivirus.Windows
{
    public partial class Recycle : Form
    {
        public Recycle()
        {
            InitializeComponent();
        }
        /*   // Recycle bin content Begin 
           Shell shell = new Shell();
           Folder folder = shell.NameSpace(@"C:\\");

           listView1.View = System.Windows.Forms.View.Details;
           resizing();

           double taille = 0;
           foreach (FolderItem2 item in folder.Items())
           {
               //Console.WriteLine("FileName:{0}     Size:{1} bytes ", item.Name, CalculateSize(item));
               listView1.Items.Add(new ListViewItem(new string[] { item.Name, CalculateSize(item).ToString() + " Mo", item.Path, item.ModifyDate.ToString() }));

               taille = taille + CalculateSize(item);

           }
           label1.Text = " Taille du contenu de la Corbeille : " + taille + " Mo";


           Marshal.FinalReleaseComObject(shell);
           Console.ReadLine();

           // End Recycle bin content
       } 
            public static double CalculateSize(FolderItem obj)
            {

                if (!obj.IsFolder)
                    return (double)Math.Round(obj.Size / Math.Pow(1024, 2), 2);

                Folder recycleBin = (Folder)obj.GetFolder;

                double size = 0;


                foreach (FolderItem2 item in recycleBin.Items())
                    size += CalculateSize(item);

                return size;

            } */

        enum RecycleFlags : int
        {
            SHRB_NOCONFIRMATION = 0x00000001, // Don't ask for confirmation
            SHRB_NOPROGRESSUI = 0x00000001, // Don't show progress
            SHRB_NOSOUND = 0x00000004 // Don't make sound when the action is executed
        }
        [DllImport("Shell32.dll", CharSet = CharSet.Unicode)]
        static extern uint SHEmptyRecycleBin(IntPtr hwnd, string pszRootPath, RecycleFlags dwFlags);


        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result;
            result = MessageBox.Show("Voullez-vous vider la Corbeille ?", "Vider la Corbeille", MessageBoxButtons.YesNo);

            // If accepted, continue with the cleaning
            if (result == DialogResult.Yes)
            {
                try
                {
                    // Execute the method with the required parameters
                    uint IsSuccess = SHEmptyRecycleBin(IntPtr.Zero, null, RecycleFlags.SHRB_NOCONFIRMATION);
                    MessageBox.Show("La Corbeille a ete vider avec Sucess", "Vider la Corbeille", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    listView1.Clear();
                    label1.Text = " Taille du contenu de la Corbeille : 0";
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("La Corbeille ne c'est pas vider suite a une erreur : \n" + ex.Message, "Vider la Corbeille", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        public void resizing()
        {
            float totalColumnWidth = 0;

            // Get the sum of all column tags
            for (int i = 0; i < listView1.Columns.Count; i++)
                totalColumnWidth += Convert.ToInt32(listView1.Columns[i].Tag);

            // Calculate the percentage of space each column should 
            // occupy in reference to the other columns and then set the 
            // width of the column to that percentage of the visible space.
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                float colPercentage = (Convert.ToInt32(listView1.Columns[i].Tag) / totalColumnWidth);
                listView1.Columns[i].Width = (int)(colPercentage * listView1.ClientRectangle.Width);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string subdir = @"C:\Users\Public\Documents\RestorePoint";
            string root = @"C:\Users\Public\Documents\RestorePoint\" + listView1.SelectedItems[0].SubItems[0].Text;
            try
            {
                string file = listView1.SelectedItems[0].SubItems[2].Text;
                if (FileSystem.FileExists(file))
                {
                    if (!System.IO.Directory.Exists(subdir))
                    {
                        System.IO.Directory.CreateDirectory(subdir);
                        FileSystem.CopyFile(file, root, true);
                        listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
                        MessageBox.Show("Le fichier '" + listView1.SelectedItems[0].SubItems[0].Text + "' \n est restorer dans le repertoire : \n '" + subdir + "'");
                    }
                    else
                    {
                        FileSystem.CopyFile(file, root, true);
                        listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
                        MessageBox.Show("Le fichier '" + listView1.SelectedItems[0].SubItems[0].Text + "' \n est restorer dans le repertoire : \n '" + subdir + "'");
                    }

                }
                else
                {
                    MessageBox.Show("Le fichier n'existe pas dans la Corbeille ");
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show("La restoration du fichier a rencontrer une erreur : \n" + ex.Message, "Clear recycle bin", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void Recycle_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            DialogResult result;
            result = MessageBox.Show("Etes vous sur de supprimer ce fichier: '" + listView1.SelectedItems[0].SubItems[0].Text + "' \n dans la corbeille ", "Supprimer fichier", MessageBoxButtons.YesNo);

            // If accepted, continue with the cleaning
            if (result == DialogResult.Yes)
            {
                try
                {
                    ListView.SelectedListViewItemCollection breakfast = this.listView1.SelectedItems;
                    foreach (ListViewItem item in breakfast)
                    {
                        string file = item.SubItems[2].Text;
                        if (FileSystem.FileExists(file))
                        {
                            FileSystem.DeleteFile(file, UIOption.AllDialogs, RecycleOption.DeletePermanently, UICancelOption.ThrowException);
                            listView1.Items.RemoveAt(listView1.SelectedIndices[0]);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    MessageBox.Show("La suppression de l'element selectionner a rencontrer une erreur : \n" + ex.Message, "Clear recycle bin", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
