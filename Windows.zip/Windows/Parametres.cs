﻿using Draka_Antivirus.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Parametres : Form
    {
        private System.Threading.ManualResetEvent _busy = new System.Threading.ManualResetEvent(false);
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "ScanDataBase.db";
        public static string sourceFile = targetPath + name_db;
        Database db1 = new Database();

        string path = @"D:\job\AGMA Organization technology inc\Draka new verison\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
        /*string path = @"C:\Program Files (x86)\Default Company Name\Setup1\Error_Log.txt";*/

        // for test
        /*string path = @"..\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";*/

        private string ScanCompletDirectory = "";
        private string ScanPartielDirectory = "";
        private string ScanDateComplet = "";
        private string ScanDatePartiel = "";
        private string StatusScanCompletDemarrage = "";
        private string StatusScanPartielDemarrage = "";
        private string Securite = "";
        private string langue = "";
        private string StatusQuarantaine = "";
        private string StatusControlParental = "";
        private string StatusMiseAJour = "";
        private string StatusBaseVirale = "";
        public Parametres()
        {
            InitializeComponent();
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            Security();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            label104.Text = folderBrowserDialog1.SelectedPath;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private string Security()
        {
            // AntiVirus
            if (guna2CustomCheckBox4.Checked == true)
            {
                Securite = "Antivirus";
                guna2CustomCheckBox3.Visible = false;
                guna2CustomCheckBox5.Visible = false;
            }
            // Anti Malware
            else if (guna2CustomCheckBox3.Checked == true)
            {
                Securite = "Anti Malware";
                guna2CustomCheckBox4.Visible = false;
                guna2CustomCheckBox5.Visible = false;
            }
            // Temps reels
            else if (guna2CustomCheckBox5.Checked == true)
            {
                Securite = "Temps reel";
                guna2CustomCheckBox4.Visible = false;
                guna2CustomCheckBox3.Visible = false;
            }
            else
            {
                Securite = "Defauts";
                guna2CustomCheckBox3.Visible = true;
                guna2CustomCheckBox4.Visible = true;
                guna2CustomCheckBox5.Visible = true;
            }

            return Securite;
        }

        private string Langue()
        {
            if (guna2CustomCheckBox8.Checked == true)
            {
                langue = "Fr";
                guna2CustomCheckBox6.Visible = false;
            }
            else if (guna2CustomCheckBox6.Checked == true)
            {
                langue = "En";
                guna2CustomCheckBox8.Visible = false;
            }
            else
            {
                langue = "Defauts";
                guna2CustomCheckBox8.Visible = true;
                guna2CustomCheckBox6.Visible = true;
            }

            return langue;
        }

        private string Quarantaine()
        {
            if (guna2CustomCheckBox9.Checked == true)
            {
                StatusQuarantaine = "Auto";
                guna2CustomCheckBox7.Visible = false;
            }
            else if (guna2CustomCheckBox7.Checked == true)
            {
                StatusQuarantaine = "Non Auto";
                guna2CustomCheckBox9.Visible = false;
            }
            else
            {
                StatusQuarantaine = "Defauts";
                guna2CustomCheckBox7.Visible = true;
                guna2CustomCheckBox9.Visible = true;
            }

            return StatusQuarantaine;
        }

        private string ControlParental()
        {
            // Control parental
            if (guna2CustomCheckBox10.Checked == true)
            {
                StatusControlParental = "Desactiver";
                guna2CustomCheckBox11.Visible = false;
            }
            else if (guna2CustomCheckBox11.Checked == true)
            {
                StatusControlParental = "Activer";
                guna2CustomCheckBox10.Visible = false;
            }
            else
            {
                StatusControlParental = "Defauts";
                guna2CustomCheckBox10.Visible = true;
                guna2CustomCheckBox11.Visible = true;
            }
            return StatusControlParental;
        }

        private string MiseAJour()
        {
            if (guna2CustomCheckBox20.Checked == true)
            {
                StatusMiseAJour = "Maintenant";
                guna2CustomCheckBox18.Visible = false;
                guna2CustomCheckBox19.Visible = false;
            }
            else if (guna2CustomCheckBox18.Checked == true)
            {
                StatusMiseAJour = "Mensuel";
                guna2CustomCheckBox19.Visible = false;
                guna2CustomCheckBox20.Visible = false;
            }
            else if (guna2CustomCheckBox19.Checked == true)
            {
                StatusMiseAJour = "Automatique";
                guna2CustomCheckBox18.Visible = false;
                guna2CustomCheckBox19.Visible = false;
            }
            else
            {
                StatusMiseAJour = "Defauts";
                guna2CustomCheckBox18.Visible = true;
                guna2CustomCheckBox19.Visible = true;
                guna2CustomCheckBox20.Visible = true;
            }

            return StatusMiseAJour;
        }

        private string BaseViral()
        {
            if (guna2CustomCheckBox16.Checked == true)
            {
                StatusBaseVirale = "Virale";
                guna2CustomCheckBox17.Visible = false;
            }
            else if (guna2CustomCheckBox17.Checked == true)
            {
                StatusBaseVirale = "Signature";
                guna2CustomCheckBox16.Visible = false;
            }
            else
            {
                StatusBaseVirale = "Defauts";
                guna2CustomCheckBox16.Visible = true;
                guna2CustomCheckBox17.Visible = true;
            }

            return StatusBaseVirale;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            // Scan Complet 
            if (Security() == "Antivirus")
            {
                ScanCompletDirectory = @"C:\Users";
            }
            else if (Security() == "Anti Malware")
            {
                ScanCompletDirectory = @"C:\Program Files";
            }
            else if (Security() == "Temps reel")
            {
                ScanCompletDirectory = @"C:\";
            }
            else if (Security() == "Defauts")
            {
                ScanCompletDirectory = @"C:\Users";
            }
            ScanDateComplet = guna2DateTimePicker1.Value.Date.ToString("yyyy-MM-dd");
            if (guna2CustomCheckBox1.Checked == true) StatusScanCompletDemarrage = "Scan Complet Demarrage";
            if (guna2CustomCheckBox1.Checked == false) StatusScanCompletDemarrage = "Scan Complet Demarrage Non";

            //Scan Partiel
            if (label104.Text == "Chemin")
            {
                ScanPartielDirectory = "Pas de chemin";
            }
            else
            {
                ScanPartielDirectory = label104.Text;
            }
            ScanDatePartiel = guna2DateTimePicker2.Value.Date.ToString("yyyy-MM-dd");
            if (guna2CustomCheckBox2.Checked == true) StatusScanPartielDemarrage = "Scan Partiel Demarrage";
            if (guna2CustomCheckBox2.Checked == false) StatusScanPartielDemarrage = "Scan Partiel Demarrage Non";

            try
            {

                // si la base de donne n'existe  pas on la criait : fait
                /*string myCommand11 = "DROP TABLE Settings";
                string myCommand111 = "CREATE TABLE Settings(Id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,ScanCompletDirectory varchar(128),ScanPartielDirectory varchar(128),ScanDateComplet varchar(128),ScanDatePartiel varchar(128),StatusScanCompletDemarrage varchar(128),StatusScanPartielDemarrage varchar(128),Securite varchar(128),Langue varchar(128),StatusQuarantaine varchar(128),StatusControlParental varchar(128),StatusMiseAJour varchar(128),StatusBaseVirale varchar(128))";
                var con1 = new SQLiteConnection("Data Source=" + sourceFile + ";");
                var cmd11 = new SQLiteCommand(myCommand11, con1);
                var cmd111 = new SQLiteCommand(myCommand111, con1);
                con1.Open();
                cmd11.ExecuteNonQuery();
                if (cmd111.ExecuteNonQuery() != 0)
                {
                    MessageBox.Show(" table FullScan creer");
                }
                con1.Close();*/
                // si la table n'existe pas on la crait : fait

                // on compte le nombre de ligne dans la table si cela est egale a 0 on insere les donne sinon on modify
                string sql = "SELECT COUNT(Id) FROM Settings; ";
                var conn = new SQLiteConnection("Data Source=" + sourceFile + ";");
                conn.Open();
                var cmd = new SQLiteCommand(sql, conn);
                Object i = cmd.ExecuteScalar();
                Int64 LastRowID64 = Int64.Parse(i.ToString());
                Console.WriteLine(LastRowID64);
                int LastRowID = (int)LastRowID64;
                conn.Close();

                if (LastRowID == 0)
                {
                    string sql2 = "insert into Settings (ScanCompletDirectory ,ScanPartielDirectory ,ScanDateComplet ,ScanDatePartiel ,StatusScanCompletDemarrage ,StatusScanPartielDemarrage ,Securite ,Langue ,StatusQuarantaine ,StatusControlParental ,StatusMiseAJour ,StatusBaseVirale) values(";
                    sql2 = sql2 + "'" + ScanCompletDirectory + "', ";
                    sql2 = sql2 + "'" + ScanPartielDirectory + "', ";
                    sql2 = sql2 + "'" + ScanDateComplet + "', ";
                    sql2 = sql2 + "'" + ScanDatePartiel + "', ";
                    sql2 = sql2 + "'" + StatusScanCompletDemarrage + "', ";
                    sql2 = sql2 + "'" + StatusScanPartielDemarrage + "', ";
                    sql2 = sql2 + "'" + Security() + "', ";
                    sql2 = sql2 + "'" + Langue() + "', ";
                    sql2 = sql2 + "'" + Quarantaine() + "', ";
                    sql2 = sql2 + "'" + ControlParental() + "', ";
                    sql2 = sql2 + "'" + MiseAJour() + "', ";
                    sql2 = sql2 + "'" + BaseViral() + "')";

                    Boolean error = db1.insertData(sourceFile, sql2);
                    if (error == true)
                    {
                        AutoClosingMessageBox.Show("Enregistrement fait avec Succes !!!!!", "Parametres", 3000);
                    }
                    else
                    {
                        Console.WriteLine("Une erreur est survenu lors de l'enregistrement de vos parametres \n Veuillez essayer de nouveau ", "Virus", 3000);
                    }
                }
                else
                {
                    using (SQLiteConnection connection = new SQLiteConnection())
                    {
                        connection.ConnectionString = "Data Source=" + sourceFile;
                        connection.Open();
                        using (SQLiteCommand command = new SQLiteCommand(connection))
                        {
                            command.CommandText =
                                "update Settings set " +
                                "ScanCompletDirectory = :ScanCompletDirectory1, " +
                                "ScanPartielDirectory = :ScanPartielDirectory1, " +
                                "ScanDateComplet = :ScanDateComplet1, " +
                                "ScanDatePartiel = :ScanDatePartiel1, " +
                                "StatusScanCompletDemarrage = :StatusScanCompletDemarrage1, " +
                                "StatusScanPartielDemarrage = :StatusScanPartielDemarrage1, " +
                                "Securite = :Securite1, " +
                                "Langue = :Langue1, " +
                                "StatusQuarantaine = :StatusQuarantaine1, " +
                                "StatusControlParental = :StatusControlParental1, " +
                                "StatusMiseAJour = :StatusMiseAJour1, " +
                                "StatusBaseVirale = :StatusBaseVirale1 " +
                                "where Id=:id;";
                            command.Parameters.Add("ScanCompletDirectory1", DbType.String).Value = ScanCompletDirectory;
                            command.Parameters.Add("ScanPartielDirectory1", DbType.String).Value = ScanPartielDirectory;
                            command.Parameters.Add("ScanDateComplet1", DbType.String).Value = ScanDateComplet;
                            command.Parameters.Add("ScanDatePartiel1", DbType.String).Value = ScanDatePartiel;
                            command.Parameters.Add("StatusScanCompletDemarrage1", DbType.String).Value = StatusScanCompletDemarrage;
                            command.Parameters.Add("StatusScanPartielDemarrage1", DbType.String).Value = StatusScanPartielDemarrage;
                            command.Parameters.Add("Securite1", DbType.String).Value = Security();
                            command.Parameters.Add("Langue1", DbType.String).Value = Langue();
                            command.Parameters.Add("StatusQuarantaine1", DbType.String).Value = Quarantaine();
                            command.Parameters.Add("StatusControlParental1", DbType.String).Value = ControlParental();
                            command.Parameters.Add("StatusMiseAJour1", DbType.String).Value = MiseAJour();
                            command.Parameters.Add("StatusBaseVirale1", DbType.String).Value = BaseViral();
                            command.Parameters.Add("id", DbType.String).Value = LastRowID;
                            if (command.ExecuteNonQuery() > 0)
                            {
                                AutoClosingMessageBox.Show("Mofification effectuer avec Succes !!!!!", "Parametres", 3000);
                            }
                            else
                            {
                                Console.WriteLine("Une erreur est survenu lors de la modification de vos parametres \n Veuillez essayer de nouveau ", "Virus", 3000);
                            }

                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Error_Message:" + ex);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Error_Message:" + ex);
                    tw.Close();
                }
            }
            /* MessageBox.Show(ScanCompletDirectory + " \n" + ScanDateComplet + " \n" + StatusScanCompletDemarrage + " \n" + ScanPartielDirectory + " \n" + ScanDatePartiel + " \n" + StatusScanPartielDemarrage + " \n" + Security() + " \n" + Langue() + " \n" + Quarantaine() + " \n" + ControlParental() + " \n" + MiseAJour() + " \n" + BaseViral());*/
        }

        private void groupBox6_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            Security();
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            Security();
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            Langue();
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            Langue();
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            Quarantaine();
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            Quarantaine();
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            ControlParental();
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            ControlParental();
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            MiseAJour();
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            MiseAJour();
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            MiseAJour();
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            BaseViral();
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            BaseViral();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button49_Click(object sender, EventArgs e)
        {
            label104.Text = folderBrowserDialog1.SelectedPath;
        }

        private void guna2Button50_Click(object sender, EventArgs e)
        {

        }

        private void guna2GroupBox4_Click(object sender, EventArgs e)
        {

        }
    }
}
