﻿namespace Draka_Antivirus.Windows
{
    partial class Performance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2Button16 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button18 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button19 = new Guna.UI2.WinForms.Guna2Button();
            this.btnSystemInformation = new Guna.UI2.WinForms.Guna2Button();
            this.system = new System.Windows.Forms.TabPage();
            this.memoire = new System.Windows.Forms.TabPage();
            this.reseau = new System.Windows.Forms.TabPage();
            this.disque = new System.Windows.Forms.TabPage();
            this.panelBodyPerformance = new System.Windows.Forms.Panel();
            this.panelBoutons = new System.Windows.Forms.Panel();
            this.panelBoutons.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Button16
            // 
            this.guna2Button16.Animated = true;
            this.guna2Button16.BorderRadius = 10;
            this.guna2Button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button16.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button16.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button16.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button16.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button16.ForeColor = System.Drawing.Color.White;
            this.guna2Button16.Location = new System.Drawing.Point(21, 184);
            this.guna2Button16.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button16.Name = "guna2Button16";
            this.guna2Button16.Size = new System.Drawing.Size(161, 56);
            this.guna2Button16.TabIndex = 4;
            this.guna2Button16.Text = "Disk";
            this.guna2Button16.Click += new System.EventHandler(this.guna2Button16_Click);
            // 
            // guna2Button17
            // 
            this.guna2Button17.Animated = true;
            this.guna2Button17.BorderRadius = 10;
            this.guna2Button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button17.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button17.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button17.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button17.ForeColor = System.Drawing.Color.White;
            this.guna2Button17.Location = new System.Drawing.Point(21, 92);
            this.guna2Button17.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.Size = new System.Drawing.Size(161, 56);
            this.guna2Button17.TabIndex = 3;
            this.guna2Button17.Text = "System Information";
            this.guna2Button17.Click += new System.EventHandler(this.guna2Button17_Click);
            // 
            // guna2Button18
            // 
            this.guna2Button18.Animated = true;
            this.guna2Button18.BorderRadius = 10;
            this.guna2Button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button18.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button18.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button18.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button18.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button18.ForeColor = System.Drawing.Color.White;
            this.guna2Button18.Location = new System.Drawing.Point(21, 363);
            this.guna2Button18.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button18.Name = "guna2Button18";
            this.guna2Button18.Size = new System.Drawing.Size(161, 56);
            this.guna2Button18.TabIndex = 7;
            this.guna2Button18.Text = "Network";
            this.guna2Button18.Click += new System.EventHandler(this.guna2Button18_Click);
            // 
            // guna2Button19
            // 
            this.guna2Button19.Animated = true;
            this.guna2Button19.BorderRadius = 10;
            this.guna2Button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button19.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button19.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button19.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button19.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button19.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button19.ForeColor = System.Drawing.Color.White;
            this.guna2Button19.Location = new System.Drawing.Point(21, 272);
            this.guna2Button19.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button19.Name = "guna2Button19";
            this.guna2Button19.Size = new System.Drawing.Size(161, 56);
            this.guna2Button19.TabIndex = 6;
            this.guna2Button19.Text = "Memory information";
            this.guna2Button19.Click += new System.EventHandler(this.guna2Button19_Click);
            // 
            // btnSystemInformation
            // 
            this.btnSystemInformation.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSystemInformation.ForeColor = System.Drawing.Color.White;
            this.btnSystemInformation.Location = new System.Drawing.Point(0, 0);
            this.btnSystemInformation.Name = "btnSystemInformation";
            this.btnSystemInformation.Size = new System.Drawing.Size(180, 45);
            this.btnSystemInformation.TabIndex = 0;
            // 
            // system
            // 
            this.system.Location = new System.Drawing.Point(0, 0);
            this.system.Name = "system";
            this.system.Size = new System.Drawing.Size(200, 100);
            this.system.TabIndex = 0;
            // 
            // memoire
            // 
            this.memoire.Location = new System.Drawing.Point(0, 0);
            this.memoire.Name = "memoire";
            this.memoire.Size = new System.Drawing.Size(200, 100);
            this.memoire.TabIndex = 0;
            // 
            // reseau
            // 
            this.reseau.Location = new System.Drawing.Point(0, 0);
            this.reseau.Name = "reseau";
            this.reseau.Size = new System.Drawing.Size(200, 100);
            this.reseau.TabIndex = 0;
            // 
            // disque
            // 
            this.disque.Location = new System.Drawing.Point(0, 0);
            this.disque.Name = "disque";
            this.disque.Size = new System.Drawing.Size(200, 100);
            this.disque.TabIndex = 0;
            // 
            // panelBodyPerformance
            // 
            this.panelBodyPerformance.BackColor = System.Drawing.Color.White;
            this.panelBodyPerformance.Location = new System.Drawing.Point(189, 4);
            this.panelBodyPerformance.Name = "panelBodyPerformance";
            this.panelBodyPerformance.Size = new System.Drawing.Size(847, 502);
            this.panelBodyPerformance.TabIndex = 1;
            // 
            // panelBoutons
            // 
            this.panelBoutons.BackColor = System.Drawing.Color.White;
            this.panelBoutons.Controls.Add(this.guna2Button17);
            this.panelBoutons.Controls.Add(this.guna2Button16);
            this.panelBoutons.Controls.Add(this.guna2Button18);
            this.panelBoutons.Controls.Add(this.guna2Button19);
            this.panelBoutons.Location = new System.Drawing.Point(-3, 0);
            this.panelBoutons.Margin = new System.Windows.Forms.Padding(2);
            this.panelBoutons.Name = "panelBoutons";
            this.panelBoutons.Size = new System.Drawing.Size(187, 506);
            this.panelBoutons.TabIndex = 2;
            this.panelBoutons.Text = "Performance";
            // 
            // Performance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1039, 511);
            this.Controls.Add(this.panelBoutons);
            this.Controls.Add(this.panelBodyPerformance);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Performance";
            this.Text = "Performance";
            this.panelBoutons.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        // private System.Windows.Forms.Panel panelMenuPerfermance;


        private Guna.UI2.WinForms.Guna2Button guna2Button16;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button18;
        private Guna.UI2.WinForms.Guna2Button guna2Button19;
        private Guna.UI2.WinForms.Guna2Button btnSystemInformation;
        private System.Windows.Forms.Panel panelBodyPerformance;
        //private System.Windows.Forms.TabPage performances;
        //private Guna.UI2.WinForms.Guna2TabControl performanceView;
        private System.Windows.Forms.TabPage system;
        private System.Windows.Forms.TabPage memoire;
        private System.Windows.Forms.TabPage reseau;
        private System.Windows.Forms.TabPage disque;
        private System.Windows.Forms.Panel panelBoutons;
    }
}