﻿using System;
using System.Collections.Generic;
using System.Management;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Memoire : Form
    {
        public Memoire()
        {

            InitializeComponent();

            //Part Information Memory

            listView1.View = View.Details;  // Afficheage des informations de la liste
            resizing();

            ManagementObjectSearcher physicalMemoryObject = new ManagementObjectSearcher("select * from Win32_PhysicalMemory ");
            int cpt = 0;
            foreach (ManagementObject obj in physicalMemoryObject.Get())
            {
                UInt64 capacity = 0;
                capacity += (UInt64)obj["Capacity"];
                listView1.Items.Add(new ListViewItem(new string[] { obj["BankLabel"].ToString(), obj["Speed"].ToString() + " MHz",
                    Math.Round(capacity/Math.Pow(1024,3),2) + " GB",obj["Name"].ToString(), obj["Manufacturer"].ToString()}));
                cpt++;
            }

            // End Part Information Memory 
        }

        public void resizing()
        {
            float totalColumnWidth = 0;

            // Get the sum of all column tags
            for (int i = 0; i < listView1.Columns.Count; i++)
                totalColumnWidth += Convert.ToInt32(listView1.Columns[i].Tag);

            // Calculate the percentage of space each column should 
            // occupy in reference to the other columns and then set the 
            // width of the column to that percentage of the visible space.
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                float colPercentage = (Convert.ToInt32(listView1.Columns[i].Tag) / totalColumnWidth);
                listView1.Columns[i].Width = (int)(colPercentage * listView1.ClientRectangle.Width);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
