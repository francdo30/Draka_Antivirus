﻿using System;
using System.Management;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class StartupSoftware : Form
    {
        public StartupSoftware()
        {
            InitializeComponent();

            // Startup Software Begin
            ManagementClass mangnmt = new ManagementClass("Win32_StartupCommand");
            ManagementObjectCollection mcol = mangnmt.GetInstances();
            listView1.View = View.Details;
            resizing();
            foreach (ManagementObject strt in mcol)
            {
                //Console.WriteLine("Application Name: "
                //+ strt["Name"].ToString());

                //Console.WriteLine("Application Location: "
                //+ strt["Location"].ToString());

                //Console.WriteLine("Application Command: "
                //+ strt["Command"].ToString());

                listView1.Items.Add(new ListViewItem(new string[] { strt["Name"].ToString(), strt["Location"].ToString(), strt["Command"].ToString(), strt["User"].ToString() }));
                //Console.WriteLine("User: " + strt["User"].ToString());
            }

            // End Startup Software 
        }

        public void resizing()
        {
            float totalColumnWidth = 0;

            // Get the sum of all column tags
            for (int i = 0; i < listView1.Columns.Count; i++)
                totalColumnWidth += Convert.ToInt32(listView1.Columns[i].Tag);

            // Calculate the percentage of space each column should 
            // occupy in reference to the other columns and then set the 
            // width of the column to that percentage of the visible space.
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                float colPercentage = (Convert.ToInt32(listView1.Columns[i].Tag) / totalColumnWidth);
                listView1.Columns[i].Width = (int)(colPercentage * listView1.ClientRectangle.Width);
            }
        }

        private void StartupSoftware_Load(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
