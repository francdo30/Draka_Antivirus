﻿using Draka_Antivirus.DAO;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Draka_Antivirus.Windows
{
    public partial class ControlParental : Form
    {
        //private static System.Timers.Timer timer;
        public static string targetPath1 = AppDomain.CurrentDomain.BaseDirectory;
        string PathDataVirale = targetPath1 + "viraldatabase.txt";
        string Path = @"C:\Windows\System32\drivers\etc";
        //public static string name_db1 = "parentalControl.db";
        public static string name_db = "ScanDataBase.db";
        string Path_pwd = targetPath1 + "PWD.txt";
        public static string sourceFile = targetPath1 + name_db;
        Database db1 = new Database();
        string passeWord = "";
        string PWD = "12345678";
        Pages_Principales.ParentalControl parentControl = new Pages_Principales.ParentalControl();

        public ControlParental()
        {
            InitializeComponent();
            //creation ou vérification de la base des données
            if (sourceFile != null)
            {
                //MessageBox.Show("je suis la base de données 8998989898989898 ");
                parentControl.parentalData();
                refreshData1();
            }
            //parent1.parentalControl(String.Empty);
        }

        public void enable_controle1(Boolean f)
        {
            textBox1.Enabled = f;
            button1.Enabled = f;
        }


        public Boolean isURL1(string url)
        {
            //création d'une uri a valeur "null"
            Uri CreatedUri;

            //on tente de créer l'url en vérifiant qu'elle est conforme a une url http ou https
            Boolean IsValid = Uri.TryCreate(url, UriKind.Absolute, out CreatedUri) && (CreatedUri.Scheme == Uri.UriSchemeHttp || CreatedUri.Scheme == Uri.UriSchemeHttps);

            if ((url != "") && (IsValid == true))
            {
                return true;// on valide l'url entrée 
                Console.WriteLine("je suis isURL en true");
            }
            else
            {
                return false;//on invalide l'url entrée
                Console.WriteLine("je suis isURL en false");
            }
        }


        public void refreshData1()
        {
            string sql = "SELECT * FROM parentControl";
            List<Object[]> datas = db1.selectDatasAuto(sourceFile, sql);
            //Object[] datas = db1.searchData(sourceFile, sql);
            dataGridView1.Rows.Clear();
            Console.WriteLine("je suis la methode refreshData1");
            
            if (datas != null)
            {                
                for (var i = 0; i < datas.Count; i++)
                {
                    dataGridView1.Rows.Add(datas[i]);
                }
            }
            else
            {
                //AutoClosingMessageBox.Show("No sites blocked");
                MessageBox.Show("No sites blocked");
            }
        }

        private void ControlParental_Load(object sender, EventArgs e)
        {
            refreshData1();
        }        
           // Add url button
        private void button1_Click(object sender, EventArgs e)
        {
            string url = textBox1.Text;
            Uri uri = new Uri(url);
            string url1 = uri.Host;
            String url2 = "127.0.0.1 " + url1;
            string status = "Bad";
            DateTime Date = DateTime.Now;
            Date.ToString("dd/MM/yyyy HH:mm:ss");
            String message = "click ajour url";

            Console.WriteLine("les valeur initialisées {0}, {1}, {2}", url2, Date, message);
            if (isURL1(url) == true)
            {
                parentControl.blocageSite(url2, url1);
                refreshData1();
                //parentControl.parentalControl(String.Empty);
            }
            else
            {
                MessageBox.Show("Invalid Url", "Error in Url", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // appeler la methode ajouter dans le host de la classe ParentalControl en utilisant la variable url2

           
        }

        // New button        
        private void button2_Click(object sender, EventArgs e)
        {
            enable_controle1(true);
            textBox1.Text = "";
            //String[] tab;
            Console.WriteLine("click bouton 2");
        }

        // Delete button 
        private void button3_Click(object sender, EventArgs e)
        {
            string message = "Do you really want to unblock this website ?";
            string caption = "No Server Name Specified";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            // Displays the MessageBox.

            result = MessageBox.Show(this, message, caption, buttons,
                MessageBoxIcon.Question, MessageBoxDefaultButton.Button1,
                MessageBoxOptions.RightAlign);

            if (result == DialogResult.Yes)
            {
                // Closes the parent form.
                //enable_controle1(false);
                //MessageBox.Show("Veuillez saisir votre mot de passe");
                PassWord pdc = new PassWord();
                pdc.ShowDialog();
                pdc.TopMost = true;

                // récupérer le Mot de passe utilisateur et autoriser la restauration du site
                passeWord = File.ReadAllText(Path_pwd);

                if (PWD.Equals(passeWord))
                {
                    enable_controle1(false);
                    Console.WriteLine("click bouton 3");
                    if (dataGridView1.SelectedRows.Count > 0)
                    {
                        string num = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                        string url = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                        string status = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                        string url2 = "127.0.0.1 " + url;

                        // appeler la methode supprimer de la classe creer en utilisant url2

                        string sql = "delete from parentControl where url='" + url + "'";
                        Boolean error = db1.deleteData(sourceFile, sql);
                        if (error == true)
                        {
                            refreshData1();
                            parentControl.deblocageSite(url);
                            MessageBox.Show("Site restore ");
                        }
                        else
                        {
                            MessageBox.Show("Database does not exist", "Internal Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        // faison aussi la suppression du site du fichier Host afin de liberer l'accès à celui-ci
                    }
                    else
                    {
                        MessageBox.Show("No line selected", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("you are not an administrator Contact Your Admin");
                }
            }
                
        }





            


        
    }
}
