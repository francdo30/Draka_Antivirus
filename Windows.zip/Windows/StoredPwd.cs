﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Draka_Antivirus.Pages_Principales;

namespace Draka_Antivirus.Windows
{
    public partial class StoredPwd : Form
    {
        public StoredPwd()
        {
            InitializeComponent();
        }

        public void getPassword()
        {
            List<IPassReader> readers = new List<IPassReader>();
            readers.Add(new FirefoxPassReader());
            /*   readers.Add(new ChromePassReader());  */
            //readers.Add(new IE10PassReader());

            foreach (var reader in readers)
            {
                try
                {
                    //ShowDetails(reader.ReadPasswords(), reader.BrowserName);

                    foreach (var d in reader.ReadPasswords())
                    {

                        dgvStoredPassword.Rows.Add(new Object[] { d.Url.ToString(), d.Username.ToString(), d.Password.ToString(), reader.BrowserName.ToString() });

                    }

                    LBL_COUNT_STORED.Text = "" + dgvStoredPassword.Rows.Count;

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error reading " + reader.BrowserName + " passwords: " + ex.Message);
                }
            }

#if DEBUG
            Console.ReadLine();
#endif
        }




        public void ShowDetails(IEnumerable<CredentialModel> data, String browser)
        {
            foreach (var d in data)
            {
                dgvStoredPassword.Rows.Add(new Object[] { d.Url, d.Username.Remove(3, 5), d.Password.Remove(3, 5), browser });
                Console.WriteLine("Url: {d.Url}, UN: {d.Username}, Pwd:{d.Password}, Browser: {browser}");
            }
        }




        private void btnScan_Click(object sender, EventArgs e)
        {
            getPassword();
        }

        private void StoredPwd_Load(object sender, EventArgs e)
        {

        }

    }
}
