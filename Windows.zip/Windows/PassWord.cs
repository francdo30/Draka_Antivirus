﻿using Microsoft.Graph;
using System;
using Draka_Antivirus.DAO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using File = System.IO.File;

namespace Draka_Antivirus.Windows
{
    public partial class PassWord : Form
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "parentalControl.db";
        public static string targetPath1 = AppDomain.CurrentDomain.BaseDirectory;
        public static string sourceFile = targetPath + name_db;
        string PathDataVirale = targetPath1 + "viraldatabase.txt";
        string passeword = targetPath1 + "PWD.txt";
        //string path = targetPath + "Error_Log.txt";
        Database db1 = new Database();
        
        public string str = "";
        public PassWord()
        {
            InitializeComponent();            
        }

        public void button1_Click(object sender, EventArgs e)
        {            
            str = textBox1.Text;
            MessageBox.Show(passeword);
            File.WriteAllText(passeword, str);            
        }
       
    }
}
