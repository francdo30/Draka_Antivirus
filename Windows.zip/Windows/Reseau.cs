﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Reseau : Form
    {
        public Reseau()
        {
            InitializeComponent();
        }
        private void Network_Load(object sender, EventArgs e)
        {
            CultureInfo provider = CultureInfo.InvariantCulture;
            NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces();
            Console.WriteLine(adapters.Length);

            foreach (NetworkInterface adapter in adapters)
            {
                if (adapter.GetIPStatistics().BytesSent > 0)
                {
                    IPAddress ipv4 = adapter.GetIPProperties().UnicastAddresses[1].Address;
                    IPInterfaceProperties adapterProperties = adapter.GetIPProperties();
                    DateTime today = DateTime.Now;
                    label3.Text = adapter.Name;
                    label19.Text = adapter.Description;
                    label20.Text = adapter.Id;
                    label21.Text = adapter.GetIPProperties().GetIPv4Properties().IsDhcpEnabled.ToString();
                    label22.Text = adapter.GetIPProperties().UnicastAddresses[1].Address.ToString();
                    label23.Text = adapter.GetIPProperties().UnicastAddresses[1].IPv4Mask.ToString();
                    label24.Text = today.ToString("yyyy:MM:dd hh:mm:ss");
                    label25.Text = today.ToString("yyyy:MM:dd hh:mm:ss");
                    label26.Text = getwayaddress();
                    label27.Text = DHCPAddress();
                    label28.Text = GetDnsAdress();
                    label29.Text = "";
                    label30.Text = ipv4.IsIPv6LinkLocal.ToString();
                    label31.Text = getipv6address();
                    label32.Text = "";
                    label33.Text = "";
                }
                else
                {
                    continue;
                }

            }

            foreach (NetworkInterface ni in adapters)
            {
                if (ni.GetIPStatistics().BytesSent > 0)
                {
                    label35.Text = "Bytes Send: " + (ni.GetIPv4Statistics().BytesSent / 1024) + " Mbps" + "      Bytes Receive: " + (ni.GetIPv4Statistics().BytesReceived / 1024) + " Mbps";
                }

            }
        }

        public string DHCPAddress()
        {
            string address1 = "";
            NetworkInterface[] adapters = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface adapter in adapters)
            {

                IPInterfaceProperties adapterProperties = adapter.GetIPProperties();
                IPAddressCollection addresses = adapterProperties.DhcpServerAddresses;
                if (addresses.Count > 0)
                {
                    Console.WriteLine(adapter.Description);
                    foreach (IPAddress address in addresses)
                    {
                        address1 = address.ToString();
                    }
                }
            }

            return address1;
        }

        public string getwayaddress()
        {
            string address2 = "";
            foreach (NetworkInterface f in NetworkInterface.GetAllNetworkInterfaces())
                if (f.OperationalStatus == OperationalStatus.Up)
                    foreach (GatewayIPAddressInformation d in f.GetIPProperties().GatewayAddresses)

                        if (d.Address.ToString().Trim().Length > 2)//ignore ::
                            address2 = d.Address.ToString();
            return address2;
        }

        private string GetDnsAdress()
        {

            NetworkInterface[] networkInterfaces = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface networkInterface in networkInterfaces)
            {
                if (networkInterface.OperationalStatus == OperationalStatus.Up)
                {
                    IPInterfaceProperties ipProperties = networkInterface.GetIPProperties();
                    IPAddressCollection dnsAddresses = ipProperties.DnsAddresses;

                    foreach (IPAddress dnsAdress in dnsAddresses)
                    {
                        return dnsAdress.ToString();
                    }
                }
            }

            throw new InvalidOperationException("Unable to find DNS Address");
        }

        public string getipv6address()
        {
            string address3 = "";
            string strHostName = System.Net.Dns.GetHostName(); ;
            IPHostEntry ipEntry = System.Net.Dns.GetHostEntry(strHostName);
            IPAddress[] addr = ipEntry.AddressList;
            Console.WriteLine(addr[addr.Length - 1].ToString());
            if (addr[0].AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
            {
                address3 = addr[0].ToString(); //ipv6
            }

            return address3;
        }

        public string NetWorkSpeed()
        {
            string speed = "";
            PerformanceCounterCategory pcg = new PerformanceCounterCategory("Network Interface");
            string instance = pcg.GetInstanceNames()[0];
            PerformanceCounter pcsent = new PerformanceCounter("Network Interface", "Bytes Sent/sec", instance);
            PerformanceCounter pcreceived = new PerformanceCounter("Network Interface", "Bytes Received/sec", instance);

            speed = "Bytes Sent: " + pcsent.NextValue() / 1024 + "   Bytes Received: " + pcreceived.NextValue() / 1024;

            return speed;
        }       

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
