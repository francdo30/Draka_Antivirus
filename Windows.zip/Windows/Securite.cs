﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Securite : Form
    {
        public Securite()
        {
            InitializeComponent();
            openChildrenForm_Security(new ControlParental());
        }
        private Form activeForm = null;
        private void openChildrenForm_Security(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelBodySecurity.Controls.Add(childForm);
            panelBodySecurity.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }


        private void btnFirewall_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new Firewall());
        }

        private void btnAntivirus_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new Antivirus());
        }
        private void btnStoredWifi_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new StoredWifi());
        }

        private void btnObjectionableWeb_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new ObjectionableWebsites());
        }

        private void btnBankCards_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new BankCards());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new ControlParental());

        }

        private void roundedButton1_Click(object sender, EventArgs e)
        {
            openChildrenForm_Security(new StoredPwd());
        }

        
    }
}
