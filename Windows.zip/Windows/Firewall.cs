﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Firewall : Form
    {
        public Firewall()
        {
            InitializeComponent();
            FirewallInstalled();
        }

        public void checkFirewall()
        {
            Type FWManagerType = Type.GetTypeFromProgID("HNetCfg.FwMgr");

            dynamic FWManager = Activator.CreateInstance(FWManagerType);
            // labelFirewallName.Text= FWManager.
            labelFirewallStatut.Text = Convert.ToString(FWManager.LocalPolicy.CurrentProfile.FirewallEnabled);

        }

        public bool FirewallInstalled()
        {

            ManagementObjectSearcher wmiData = new ManagementObjectSearcher(@"root\SecurityCenter2", "SELECT * FROM AntiVirusProduct");
            ManagementObjectCollection data = wmiData.Get();
            ManagementObject firewall = data.OfType<ManagementObject>().First();
            labelFirewallName.Text = firewall["displayName"].ToString();
            String state = firewall["productState"].ToString();
            switch (state)
            {
                case "397568"://Windows defender
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "True";
                    break;
                case "397584"://Windows defender
                    labelFirewallSignature.Text = "Out to date";
                    labelFirewallStatut.Text = "True";
                    break;
                case "393472"://Windows defender
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "False";
                    break;
                case "397312"://Microsoft security essentials
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "True";
                    break;
                case "393216"://Microsoft security essentials
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "False";
                    break;
                case "266256"://AVG Internet Security 2012 firewall product
                    labelFirewallSignature.Text = "Firewall";
                    labelFirewallStatut.Text = "True";
                    break;
                case "262160"://AVG Internet Security 2012 firewall product
                    labelFirewallSignature.Text = "Firewall";
                    labelFirewallStatut.Text = "False";
                    break;
                case "262144"://AVG Internet Security 2012 antivirus product
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "False";
                    break;
                case "266240"://AVG Internet Security 2012 antivirus product
                    labelFirewallSignature.Text = "Up to date";
                    labelFirewallStatut.Text = "True";
                    break;
                default://We don't have information about product
                    labelFirewallSignature.Text = "--";
                    labelFirewallStatut.Text = "False";
                    break;
            }

            return false;
        }

        private void labelFirewallName_Click(object sender, EventArgs e)
        {

        }
    }
}
