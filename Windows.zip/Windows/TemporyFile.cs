﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class TemporyFile : Form
    {
        public TemporyFile()
        {
            InitializeComponent();

            // Temporary Files Begin
            DirectoryInfo Dir = new DirectoryInfo(System.IO.Path.GetTempPath());
            string tempFile = Path.GetTempPath();

            FileInfo[] Files = Dir.GetFiles();
            int i = 0;
            int taill = 0;
            listView1.View = View.Details;
            resizing();
            foreach (FileInfo file in Files)
            {
                //Console.WriteLine((int)file.Length);
                /* taill = taill + (int)file.Length;*/
                taill = (int)file.Length;
                listView1.Items.Add(new ListViewItem(new string[] { file.Name, taill + " Bytes", i.ToString() }));
                i++;
            }
            // End Temporary File 
        }

        public void resizing()
        {
            float totalColumnWidth = 0;

            // Get the sum of all column tags
            for (int i = 0; i < listView1.Columns.Count; i++)
                totalColumnWidth += Convert.ToInt32(listView1.Columns[i].Tag);

            // Calculate the percentage of space each column should 
            // occupy in reference to the other columns and then set the 
            // width of the column to that percentage of the visible space.
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                float colPercentage = (Convert.ToInt32(listView1.Columns[i].Tag) / totalColumnWidth);
                listView1.Columns[i].Width = (int)(colPercentage * listView1.ClientRectangle.Width);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TemporyFile_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DirectoryInfo Dir1 = new DirectoryInfo(System.IO.Path.GetTempPath());
            string tempFile1 = Path.GetTempPath();

            FileInfo[] Files1 = Dir1.GetFiles();
            int i1 = 0;
            listView1.View = View.Details;
            resizing();
            foreach (FileInfo file1 in Files1)
            {
                File.Delete(file1.ToString());
                i1++;
            }

            listView1.Clear();
        }
    }
}
