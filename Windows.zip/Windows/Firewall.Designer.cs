﻿namespace Draka_Antivirus.Windows
{
    partial class Firewall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelFirewallName = new System.Windows.Forms.Label();
            this.labelFirewallStatut = new System.Windows.Forms.Label();
            this.labelFirewallSignature = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(242, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Product Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(300, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Enabled :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft New Tai Lue", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(284, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Signature :";
            // 
            // labelFirewallName
            // 
            this.labelFirewallName.AutoSize = true;
            this.labelFirewallName.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFirewallName.ForeColor = System.Drawing.Color.Black;
            this.labelFirewallName.Location = new System.Drawing.Point(414, 178);
            this.labelFirewallName.Name = "labelFirewallName";
            this.labelFirewallName.Size = new System.Drawing.Size(50, 20);
            this.labelFirewallName.TabIndex = 10;
            this.labelFirewallName.Text = "label5";
            this.labelFirewallName.Click += new System.EventHandler(this.labelFirewallName_Click);
            // 
            // labelFirewallStatut
            // 
            this.labelFirewallStatut.AutoSize = true;
            this.labelFirewallStatut.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFirewallStatut.ForeColor = System.Drawing.Color.Black;
            this.labelFirewallStatut.Location = new System.Drawing.Point(414, 223);
            this.labelFirewallStatut.Name = "labelFirewallStatut";
            this.labelFirewallStatut.Size = new System.Drawing.Size(50, 20);
            this.labelFirewallStatut.TabIndex = 9;
            this.labelFirewallStatut.Text = "label5";
            // 
            // labelFirewallSignature
            // 
            this.labelFirewallSignature.AutoSize = true;
            this.labelFirewallSignature.Font = new System.Drawing.Font("Microsoft New Tai Lue", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelFirewallSignature.ForeColor = System.Drawing.Color.Black;
            this.labelFirewallSignature.Location = new System.Drawing.Point(414, 270);
            this.labelFirewallSignature.Name = "labelFirewallSignature";
            this.labelFirewallSignature.Size = new System.Drawing.Size(50, 20);
            this.labelFirewallSignature.TabIndex = 8;
            this.labelFirewallSignature.Text = "label5";
            // 
            // Firewall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(818, 511);
            this.Controls.Add(this.labelFirewallSignature);
            this.Controls.Add(this.labelFirewallStatut);
            this.Controls.Add(this.labelFirewallName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Firewall";
            this.Text = "Firewall";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelFirewallName;
        private System.Windows.Forms.Label labelFirewallStatut;
        private System.Windows.Forms.Label labelFirewallSignature;
    }
}