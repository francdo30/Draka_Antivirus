﻿using Draka_Antivirus.DAO;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Web;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class BankCards : Form
    {
        public static string targetPath = AppDomain.CurrentDomain.BaseDirectory;
        public static string name_db = "Login Data.db";
        public static string sourceFile = targetPath + name_db;
        Database db = new Database();
        Pages_Principales.ParentalControl parent = new Pages_Principales.ParentalControl();

        string path = @"D:\job\AGMA Organization technology inc\Draka new verison\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
        /*string path = @"C:\Program Files (x86)\Default Company Name\Setup1\Error_Log.txt";*/
        /*string path_test = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";*/


        public BankCards()
        {
            InitializeComponent();
        }
        // Convert an object to a byte array
        private byte[] ObjectToByteArray(Object obj)
        {
            if (obj == null)
                return null;

            BinaryFormatter bf = new BinaryFormatter();
            MemoryStream ms = new MemoryStream();
            bf.Serialize(ms, obj);

            return ms.ToArray();
        }



        // Convert a byte array to an Object
        private Object ByteArrayToObject(byte[] arrBytes)
        {
            MemoryStream memStream = new MemoryStream();
            BinaryFormatter binForm = new BinaryFormatter();
            memStream.Write(arrBytes, 0, arrBytes.Length);
            memStream.Seek(0, SeekOrigin.Begin);
            Object obj = (Object)binForm.Deserialize(memStream);

            return obj;
        }


        public string BinaryToText(byte[] data)
        {
            return Encoding.UTF8.GetString(data);
        }


        public Boolean urlBankcard(string url)
        {
            Boolean b = false;

            if (url.Contains("credit") == true) { b = true; }
            else if (url.Contains("banque") == true) { b = true; }
            else if (url.Contains("caisse") == true) { b = true; }
            else if (url.Contains("epargne") == true) { b = true; }
            else if (url.Contains("mutuel") == true) { b = true; }
            else if (url.Contains("populaire") == true) { b = true; }
            else if (url.Contains("credit agricole") == true) { b = true; }
            else if (url.Contains("banque verte") == true) { b = true; }
            else if (url.Contains("credit mutuel") == true) { b = true; }
            else if (url.Contains("bnp baribas") == true) { b = true; }
            else if (url.Contains("lcl") == true) { b = true; }
            else if (url.Contains("cic") == true) { b = true; }
            else if (url.Contains("accord") == true) { b = true; }
            else if (url.Contains("jumia") == true) { b = true; }
            else if (url.Contains("alibaba") == true) { b = true; }
            else if (url.Contains("amazon") == true) { b = true; }

            return b;
        }

        public string get_card_number()
        {
            string card_number = "";

            ChromeDriver driver = new ChromeDriver(@"D:\job\AGMA Organization technology inc\Draka new verison\Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug");
            /*ChromeDriver driver = new ChromeDriver(@"C:\Program Files (x86)\Default Company Name\Setup1");*/

            // for test
            /*ChromeDriver driver = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug";*/

            try
            {
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls
                       | SecurityProtocolType.Tls11
                       | SecurityProtocolType.Tls12
                       | SecurityProtocolType.Ssl3;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://google.com/api/");
                /*driver.Navigate().GoToUrl("http://pay.google.com/gp/w/home/paymentmethods");*/
                /* string local_storage = driver.HasWebStorage.ToString();*/
                WebClient wc = new System.Net.WebClient();
                string webData = wc.DownloadString("https://pay.google.com/gp/w/home/paymentmethods?sctid=?");
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + webData);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + " " + "Request:" + " " + webData);
                    tw.Close();
                }

                driver.Close();
            }
            catch (Exception e)
            {
                if (!File.Exists(path))
                {
                    File.Create(path);
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + "Error_Message:" + e);
                    tw.Close();
                }

                else if (File.Exists(path))
                {
                    TextWriter tw = new StreamWriter(path, true);
                    tw.WriteLine(DateTime.Now.ToString() + "Error_Message:" + e);
                    tw.Close();
                }
            }

            return card_number;
        }


        public void refreshData()
        {
            get_card_number();
            List<Object[]> datas = db.selectDatas(sourceFile, "select * from logins");

            if (datas != null)
            {
                for (var i = 0; i < datas.Count; i++)
                {
                    if (urlBankcard(Convert.ToString(datas[i][0]).ToLower()) == true)
                    {
                        dgvBankcards.Rows.Add(
                            new Object[] {
                                datas[i][0],
                                datas[i][1],
                                datas[i][2],
                                datas[i][3],
                                //datas[i][5]
                                //"FF " + FFDecryptor.Decrypt(Convert.ToString(datas[i][5]))
                            }
                        );
                    }
                }
            }


            LBL_COUNT_BANKCARDS.Text = "" + dgvBankcards.Rows.Count;
        }




        private void btnScan_Click(object sender, EventArgs e)
        {
            refreshData();
        }

        private void dgvBankcards_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BankCards_Load(object sender, EventArgs e)
        {

        }

        private void LBL_COUNT_BANKCARDS_Click(object sender, EventArgs e)
        {

        }
    }
}
