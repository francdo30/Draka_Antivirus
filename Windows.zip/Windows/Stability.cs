﻿using Draka_Antivirus.Windows;
using System;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Stability : Form
    {
        public Stability()
        {
            InitializeComponent();
            openChildren_Stability(new AllProgram());
        }

        private Form activeForm = null;
        private void openChildren_Stability(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelBodyStability.Controls.Add(childForm);
            panelBodyStability.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnAllProgram_Click(object sender, EventArgs e)
        {
            openChildren_Stability(new AllProgram());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildren_Stability(new FrequentlyCrashingPrograms());
        }

        private void btnEventLog_Click(object sender, EventArgs e)
        {
            openChildren_Stability(new EventLogAlert());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildren_Stability(new RestorePoints());
        }

        private void Stability_Load(object sender, EventArgs e)
        {

        }
    }
}
