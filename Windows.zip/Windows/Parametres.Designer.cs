﻿namespace Draka_Antivirus.Windows
{
    partial class Parametres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button17 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button50 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button49 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button51 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Button52 = new Guna.UI2.WinForms.Guna2Button();
            this.restaure = new Guna.UI2.WinForms.Guna2Button();
            this.guna2DataGridView5 = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.custom_progressBar = new Guna.UI2.WinForms.Guna2ProgressBar();
            this.custom_ProgressIndicator = new Guna.UI2.WinForms.Guna2ProgressIndicator();
            this.setting = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GroupBox9 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox12 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox16 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label121 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox17 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label122 = new System.Windows.Forms.Label();
            this.guna2GroupBox13 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox18 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label123 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox19 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label124 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox20 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label125 = new System.Windows.Forms.Label();
            this.guna2Panel14 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GroupBox4 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox8 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox10 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label115 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox11 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label116 = new System.Windows.Forms.Label();
            this.guna2GroupBox7 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox7 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label112 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox9 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label114 = new System.Windows.Forms.Label();
            this.guna2GroupBox5 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox6 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label110 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox8 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label113 = new System.Windows.Forms.Label();
            this.guna2GroupBox6 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox5 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label109 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox3 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label108 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox4 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.label111 = new System.Windows.Forms.Label();
            this.guna2Panel13 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GroupBox1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox2 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2DateTimePicker2 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2GroupBox2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox1 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.aide = new Guna.UI2.WinForms.Guna2Panel();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.guna2GroupBox10 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2GroupBox11 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.guna2CustomCheckBox12 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox13 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox14 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox15 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel5 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel6 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel7 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel8 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel9 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel10 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel11 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel12 = new Guna.UI2.WinForms.Guna2Panel();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView5)).BeginInit();
            this.setting.SuspendLayout();
            this.guna2GroupBox9.SuspendLayout();
            this.guna2GroupBox12.SuspendLayout();
            this.guna2GroupBox13.SuspendLayout();
            this.guna2Panel14.SuspendLayout();
            this.guna2GroupBox4.SuspendLayout();
            this.guna2GroupBox8.SuspendLayout();
            this.guna2GroupBox7.SuspendLayout();
            this.guna2GroupBox5.SuspendLayout();
            this.guna2GroupBox6.SuspendLayout();
            this.guna2GroupBox1.SuspendLayout();
            this.guna2GroupBox3.SuspendLayout();
            this.guna2Panel3.SuspendLayout();
            this.guna2GroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Button3
            // 
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.White;
            this.guna2Button3.Location = new System.Drawing.Point(0, 0);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.Size = new System.Drawing.Size(180, 45);
            this.guna2Button3.TabIndex = 0;
            // 
            // guna2Button2
            // 
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.White;
            this.guna2Button2.Location = new System.Drawing.Point(0, 0);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.Size = new System.Drawing.Size(180, 45);
            this.guna2Button2.TabIndex = 0;
            // 
            // guna2Button17
            // 
            this.guna2Button17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button17.ForeColor = System.Drawing.Color.White;
            this.guna2Button17.Location = new System.Drawing.Point(0, 0);
            this.guna2Button17.Name = "guna2Button17";
            this.guna2Button17.Size = new System.Drawing.Size(180, 45);
            this.guna2Button17.TabIndex = 0;
            // 
            // guna2Button50
            // 
            this.guna2Button50.Animated = true;
            this.guna2Button50.BorderRadius = 10;
            this.guna2Button50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button50.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button50.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button50.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button50.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button50.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button50.ForeColor = System.Drawing.Color.White;
            this.guna2Button50.Location = new System.Drawing.Point(596, 43);
            this.guna2Button50.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button50.Name = "guna2Button50";
            this.guna2Button50.Size = new System.Drawing.Size(141, 38);
            this.guna2Button50.TabIndex = 28;
            this.guna2Button50.Text = "Enregistrer";
            this.guna2Button50.Click += new System.EventHandler(this.guna2Button50_Click);
            // 
            // guna2Button49
            // 
            this.guna2Button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button49.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button49.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button49.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button49.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button49.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2Button49.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button49.ForeColor = System.Drawing.Color.White;
            this.guna2Button49.Location = new System.Drawing.Point(0, 0);
            this.guna2Button49.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button49.Name = "guna2Button49";
            this.guna2Button49.Size = new System.Drawing.Size(191, 27);
            this.guna2Button49.TabIndex = 29;
            this.guna2Button49.Text = "Select file";
            // 
            // guna2Button51
            // 
            this.guna2Button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button51.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button51.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button51.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button51.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button51.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button51.ForeColor = System.Drawing.Color.White;
            this.guna2Button51.Location = new System.Drawing.Point(265, 232);
            this.guna2Button51.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button51.Name = "guna2Button51";
            this.guna2Button51.Size = new System.Drawing.Size(158, 27);
            this.guna2Button51.TabIndex = 42;
            this.guna2Button51.Text = "Sélectionner fichier";
            // 
            // guna2Button52
            // 
            this.guna2Button52.BorderRadius = 8;
            this.guna2Button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2Button52.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button52.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button52.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button52.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button52.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2Button52.ForeColor = System.Drawing.Color.White;
            this.guna2Button52.Location = new System.Drawing.Point(577, 411);
            this.guna2Button52.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Button52.Name = "guna2Button52";
            this.guna2Button52.Size = new System.Drawing.Size(142, 29);
            this.guna2Button52.TabIndex = 44;
            this.guna2Button52.Text = "Envoyer";
            // 
            // restaure
            // 
            this.restaure.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.restaure.ForeColor = System.Drawing.Color.White;
            this.restaure.Location = new System.Drawing.Point(0, 0);
            this.restaure.Name = "restaure";
            this.restaure.Size = new System.Drawing.Size(180, 45);
            this.restaure.TabIndex = 0;
            // 
            // guna2DataGridView5
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView5.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.guna2DataGridView5.BackgroundColor = System.Drawing.Color.White;
            this.guna2DataGridView5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.guna2DataGridView5.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView5.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView5.ColumnHeadersHeight = 29;
            this.guna2DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView5.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView5.EnableHeadersVisualStyles = false;
            this.guna2DataGridView5.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView5.Location = new System.Drawing.Point(0, 0);
            this.guna2DataGridView5.Name = "guna2DataGridView5";
            this.guna2DataGridView5.RowHeadersVisible = false;
            this.guna2DataGridView5.RowHeadersWidth = 51;
            this.guna2DataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.guna2DataGridView5.Size = new System.Drawing.Size(240, 150);
            this.guna2DataGridView5.TabIndex = 0;
            this.guna2DataGridView5.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView5.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView5.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView5.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView5.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView5.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView5.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.guna2DataGridView5.ThemeStyle.HeaderStyle.Height = 29;
            this.guna2DataGridView5.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView5.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView5.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView5.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Segoe UI", 10.5F);
            this.guna2DataGridView5.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView5.ThemeStyle.RowsStyle.Height = 22;
            this.guna2DataGridView5.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView5.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.Size = new System.Drawing.Size(180, 45);
            this.guna2GradientButton1.TabIndex = 0;
            // 
            // custom_progressBar
            // 
            this.custom_progressBar.Location = new System.Drawing.Point(0, 0);
            this.custom_progressBar.Name = "custom_progressBar";
            this.custom_progressBar.Size = new System.Drawing.Size(300, 30);
            this.custom_progressBar.TabIndex = 0;
            this.custom_progressBar.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            // 
            // custom_ProgressIndicator
            // 
            this.custom_ProgressIndicator.Location = new System.Drawing.Point(0, 0);
            this.custom_ProgressIndicator.Name = "custom_ProgressIndicator";
            this.custom_ProgressIndicator.Size = new System.Drawing.Size(90, 90);
            this.custom_ProgressIndicator.TabIndex = 0;
            // 
            // setting
            // 
            this.setting.BackColor = System.Drawing.Color.White;
            this.setting.Controls.Add(this.guna2GroupBox9);
            this.setting.Controls.Add(this.guna2GroupBox4);
            this.setting.Controls.Add(this.guna2GroupBox1);
            this.setting.Location = new System.Drawing.Point(141, 1);
            this.setting.Margin = new System.Windows.Forms.Padding(2);
            this.setting.Name = "setting";
            this.setting.Size = new System.Drawing.Size(789, 505);
            this.setting.TabIndex = 9;
            this.setting.Text = "Paramètres";
            // 
            // guna2GroupBox9
            // 
            this.guna2GroupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2GroupBox9.BorderRadius = 8;
            this.guna2GroupBox9.Controls.Add(this.guna2GroupBox12);
            this.guna2GroupBox9.Controls.Add(this.guna2GroupBox13);
            this.guna2GroupBox9.Controls.Add(this.guna2Panel14);
            this.guna2GroupBox9.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2GroupBox9.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox9.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox9.Location = new System.Drawing.Point(8, 327);
            this.guna2GroupBox9.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox9.Name = "guna2GroupBox9";
            this.guna2GroupBox9.Size = new System.Drawing.Size(766, 126);
            this.guna2GroupBox9.TabIndex = 19;
            this.guna2GroupBox9.Text = "Update";
            // 
            // guna2GroupBox12
            // 
            this.guna2GroupBox12.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox12.BorderRadius = 8;
            this.guna2GroupBox12.Controls.Add(this.guna2CustomCheckBox16);
            this.guna2GroupBox12.Controls.Add(this.label121);
            this.guna2GroupBox12.Controls.Add(this.guna2CustomCheckBox17);
            this.guna2GroupBox12.Controls.Add(this.label122);
            this.guna2GroupBox12.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox12.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox12.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox12.Location = new System.Drawing.Point(309, 39);
            this.guna2GroupBox12.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox12.Name = "guna2GroupBox12";
            this.guna2GroupBox12.Size = new System.Drawing.Size(165, 80);
            this.guna2GroupBox12.TabIndex = 16;
            this.guna2GroupBox12.Text = "Viral basis";
            // 
            // guna2CustomCheckBox16
            // 
            this.guna2CustomCheckBox16.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox16.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox16.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox16.Location = new System.Drawing.Point(8, 62);
            this.guna2CustomCheckBox16.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox16.Name = "guna2CustomCheckBox16";
            this.guna2CustomCheckBox16.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox16.TabIndex = 15;
            this.guna2CustomCheckBox16.Text = "active";
            this.guna2CustomCheckBox16.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox16.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox16.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox16.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label121
            // 
            this.label121.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.Location = new System.Drawing.Point(25, 55);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(129, 25);
            this.label121.TabIndex = 14;
            this.label121.Text = "Signature";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox17
            // 
            this.guna2CustomCheckBox17.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox17.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox17.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox17.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox17.Location = new System.Drawing.Point(8, 38);
            this.guna2CustomCheckBox17.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox17.Name = "guna2CustomCheckBox17";
            this.guna2CustomCheckBox17.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox17.TabIndex = 11;
            this.guna2CustomCheckBox17.Text = "active";
            this.guna2CustomCheckBox17.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox17.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox17.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox17.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label122
            // 
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.Location = new System.Drawing.Point(25, 34);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(88, 25);
            this.label122.TabIndex = 9;
            this.label122.Text = "Viral";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2GroupBox13
            // 
            this.guna2GroupBox13.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox13.BorderRadius = 8;
            this.guna2GroupBox13.Controls.Add(this.guna2CustomCheckBox18);
            this.guna2GroupBox13.Controls.Add(this.label123);
            this.guna2GroupBox13.Controls.Add(this.guna2CustomCheckBox19);
            this.guna2GroupBox13.Controls.Add(this.label124);
            this.guna2GroupBox13.Controls.Add(this.guna2CustomCheckBox20);
            this.guna2GroupBox13.Controls.Add(this.label125);
            this.guna2GroupBox13.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox13.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox13.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox13.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox13.Location = new System.Drawing.Point(2, 39);
            this.guna2GroupBox13.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox13.Name = "guna2GroupBox13";
            this.guna2GroupBox13.Size = new System.Drawing.Size(284, 80);
            this.guna2GroupBox13.TabIndex = 1;
            this.guna2GroupBox13.Text = "Application";
            // 
            // guna2CustomCheckBox18
            // 
            this.guna2CustomCheckBox18.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox18.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox18.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox18.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox18.Location = new System.Drawing.Point(15, 65);
            this.guna2CustomCheckBox18.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox18.Name = "guna2CustomCheckBox18";
            this.guna2CustomCheckBox18.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox18.TabIndex = 15;
            this.guna2CustomCheckBox18.Text = "active";
            this.guna2CustomCheckBox18.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox18.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox18.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox18.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label123
            // 
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label123.Location = new System.Drawing.Point(32, 58);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(103, 29);
            this.label123.TabIndex = 14;
            this.label123.Text = "Manual";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox19
            // 
            this.guna2CustomCheckBox19.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox19.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox19.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox19.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox19.Location = new System.Drawing.Point(154, 40);
            this.guna2CustomCheckBox19.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox19.Name = "guna2CustomCheckBox19";
            this.guna2CustomCheckBox19.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox19.TabIndex = 13;
            this.guna2CustomCheckBox19.Text = "active";
            this.guna2CustomCheckBox19.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox19.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox19.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox19.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label124
            // 
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.Location = new System.Drawing.Point(168, 30);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(132, 31);
            this.label124.TabIndex = 12;
            this.label124.Text = "Automatique";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox20
            // 
            this.guna2CustomCheckBox20.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox20.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox20.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox20.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox20.Location = new System.Drawing.Point(15, 38);
            this.guna2CustomCheckBox20.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox20.Name = "guna2CustomCheckBox20";
            this.guna2CustomCheckBox20.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox20.TabIndex = 11;
            this.guna2CustomCheckBox20.Text = "active";
            this.guna2CustomCheckBox20.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox20.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox20.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox20.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label125
            // 
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.Location = new System.Drawing.Point(32, 30);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(124, 29);
            this.label125.TabIndex = 9;
            this.label125.Text = "Now";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2Panel14
            // 
            this.guna2Panel14.BackColor = System.Drawing.Color.White;
            this.guna2Panel14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2Panel14.BorderRadius = 8;
            this.guna2Panel14.Controls.Add(this.guna2Button50);
            this.guna2Panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel14.Location = new System.Drawing.Point(0, 34);
            this.guna2Panel14.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Panel14.Name = "guna2Panel14";
            this.guna2Panel14.Size = new System.Drawing.Size(766, 92);
            this.guna2Panel14.TabIndex = 29;
            // 
            // guna2GroupBox4
            // 
            this.guna2GroupBox4.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox4.BorderColor = System.Drawing.Color.White;
            this.guna2GroupBox4.BorderRadius = 8;
            this.guna2GroupBox4.Controls.Add(this.guna2GroupBox8);
            this.guna2GroupBox4.Controls.Add(this.guna2GroupBox7);
            this.guna2GroupBox4.Controls.Add(this.guna2GroupBox5);
            this.guna2GroupBox4.Controls.Add(this.guna2GroupBox6);
            this.guna2GroupBox4.Controls.Add(this.guna2Panel13);
            this.guna2GroupBox4.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2GroupBox4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox4.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox4.Location = new System.Drawing.Point(8, 185);
            this.guna2GroupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox4.Name = "guna2GroupBox4";
            this.guna2GroupBox4.Size = new System.Drawing.Size(766, 138);
            this.guna2GroupBox4.TabIndex = 3;
            this.guna2GroupBox4.Text = "Security and Language";
            // 
            // guna2GroupBox8
            // 
            this.guna2GroupBox8.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox8.BorderRadius = 8;
            this.guna2GroupBox8.Controls.Add(this.guna2CustomCheckBox10);
            this.guna2GroupBox8.Controls.Add(this.label115);
            this.guna2GroupBox8.Controls.Add(this.guna2CustomCheckBox11);
            this.guna2GroupBox8.Controls.Add(this.label116);
            this.guna2GroupBox8.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox8.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox8.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox8.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox8.Location = new System.Drawing.Point(597, 40);
            this.guna2GroupBox8.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox8.Name = "guna2GroupBox8";
            this.guna2GroupBox8.Size = new System.Drawing.Size(167, 94);
            this.guna2GroupBox8.TabIndex = 18;
            this.guna2GroupBox8.Text = "parental Control";
            // 
            // guna2CustomCheckBox10
            // 
            this.guna2CustomCheckBox10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox10.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox10.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox10.Location = new System.Drawing.Point(15, 68);
            this.guna2CustomCheckBox10.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox10.Name = "guna2CustomCheckBox10";
            this.guna2CustomCheckBox10.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox10.TabIndex = 15;
            this.guna2CustomCheckBox10.Text = "active";
            this.guna2CustomCheckBox10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox10.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox10.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox10.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label115
            // 
            this.label115.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.Location = new System.Drawing.Point(38, 64);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(101, 24);
            this.label115.TabIndex = 14;
            this.label115.Text = "Desable";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox11
            // 
            this.guna2CustomCheckBox11.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox11.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox11.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox11.Location = new System.Drawing.Point(15, 41);
            this.guna2CustomCheckBox11.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox11.Name = "guna2CustomCheckBox11";
            this.guna2CustomCheckBox11.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox11.TabIndex = 11;
            this.guna2CustomCheckBox11.Text = "active";
            this.guna2CustomCheckBox11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox11.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox11.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox11.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label116
            // 
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.Location = new System.Drawing.Point(38, 33);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(101, 24);
            this.label116.TabIndex = 9;
            this.label116.Text = "Enable";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2GroupBox7
            // 
            this.guna2GroupBox7.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox7.BorderRadius = 8;
            this.guna2GroupBox7.Controls.Add(this.guna2CustomCheckBox7);
            this.guna2GroupBox7.Controls.Add(this.label112);
            this.guna2GroupBox7.Controls.Add(this.guna2CustomCheckBox9);
            this.guna2GroupBox7.Controls.Add(this.label114);
            this.guna2GroupBox7.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox7.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox7.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox7.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox7.Location = new System.Drawing.Point(437, 40);
            this.guna2GroupBox7.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox7.Name = "guna2GroupBox7";
            this.guna2GroupBox7.Size = new System.Drawing.Size(148, 94);
            this.guna2GroupBox7.TabIndex = 17;
            this.guna2GroupBox7.Text = "Quarantaine";
            // 
            // guna2CustomCheckBox7
            // 
            this.guna2CustomCheckBox7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox7.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox7.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox7.Location = new System.Drawing.Point(15, 68);
            this.guna2CustomCheckBox7.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox7.Name = "guna2CustomCheckBox7";
            this.guna2CustomCheckBox7.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox7.TabIndex = 15;
            this.guna2CustomCheckBox7.Text = "active";
            this.guna2CustomCheckBox7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox7.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox7.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label112
            // 
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.Location = new System.Drawing.Point(33, 64);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(112, 24);
            this.label112.TabIndex = 14;
            this.label112.Text = "Manual";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox9
            // 
            this.guna2CustomCheckBox9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox9.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox9.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox9.Location = new System.Drawing.Point(15, 41);
            this.guna2CustomCheckBox9.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox9.Name = "guna2CustomCheckBox9";
            this.guna2CustomCheckBox9.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox9.TabIndex = 11;
            this.guna2CustomCheckBox9.Text = "active";
            this.guna2CustomCheckBox9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox9.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox9.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label114
            // 
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.Location = new System.Drawing.Point(33, 33);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(137, 27);
            this.label114.TabIndex = 9;
            this.label114.Text = "Automatique";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2GroupBox5
            // 
            this.guna2GroupBox5.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox5.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox5.BorderRadius = 8;
            this.guna2GroupBox5.Controls.Add(this.guna2CustomCheckBox6);
            this.guna2GroupBox5.Controls.Add(this.label110);
            this.guna2GroupBox5.Controls.Add(this.guna2CustomCheckBox8);
            this.guna2GroupBox5.Controls.Add(this.label113);
            this.guna2GroupBox5.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox5.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox5.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox5.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox5.Location = new System.Drawing.Point(268, 40);
            this.guna2GroupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox5.Name = "guna2GroupBox5";
            this.guna2GroupBox5.Size = new System.Drawing.Size(154, 94);
            this.guna2GroupBox5.TabIndex = 16;
            this.guna2GroupBox5.Text = "Language";
            // 
            // guna2CustomCheckBox6
            // 
            this.guna2CustomCheckBox6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox6.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox6.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox6.Location = new System.Drawing.Point(15, 72);
            this.guna2CustomCheckBox6.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox6.Name = "guna2CustomCheckBox6";
            this.guna2CustomCheckBox6.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox6.TabIndex = 15;
            this.guna2CustomCheckBox6.Text = "active";
            this.guna2CustomCheckBox6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox6.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox6.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label110
            // 
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.Location = new System.Drawing.Point(34, 58);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(117, 36);
            this.label110.TabIndex = 14;
            this.label110.Text = "English";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox8
            // 
            this.guna2CustomCheckBox8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox8.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox8.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox8.Location = new System.Drawing.Point(15, 41);
            this.guna2CustomCheckBox8.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox8.Name = "guna2CustomCheckBox8";
            this.guna2CustomCheckBox8.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox8.TabIndex = 11;
            this.guna2CustomCheckBox8.Text = "active";
            this.guna2CustomCheckBox8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox8.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox8.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox8.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label113
            // 
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.Location = new System.Drawing.Point(34, 36);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(117, 23);
            this.label113.TabIndex = 9;
            this.label113.Text = "French";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2GroupBox6
            // 
            this.guna2GroupBox6.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox6.BorderRadius = 8;
            this.guna2GroupBox6.Controls.Add(this.guna2CustomCheckBox5);
            this.guna2GroupBox6.Controls.Add(this.label109);
            this.guna2GroupBox6.Controls.Add(this.guna2CustomCheckBox3);
            this.guna2GroupBox6.Controls.Add(this.label108);
            this.guna2GroupBox6.Controls.Add(this.guna2CustomCheckBox4);
            this.guna2GroupBox6.Controls.Add(this.label111);
            this.guna2GroupBox6.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox6.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox6.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox6.Location = new System.Drawing.Point(2, 40);
            this.guna2GroupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox6.Name = "guna2GroupBox6";
            this.guna2GroupBox6.Size = new System.Drawing.Size(256, 94);
            this.guna2GroupBox6.TabIndex = 1;
            this.guna2GroupBox6.Text = "Sécurity";
            // 
            // guna2CustomCheckBox5
            // 
            this.guna2CustomCheckBox5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox5.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox5.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox5.Location = new System.Drawing.Point(16, 70);
            this.guna2CustomCheckBox5.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox5.Name = "guna2CustomCheckBox5";
            this.guna2CustomCheckBox5.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox5.TabIndex = 15;
            this.guna2CustomCheckBox5.Text = "active";
            this.guna2CustomCheckBox5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox5.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox5.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label109
            // 
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.Location = new System.Drawing.Point(32, 64);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(138, 24);
            this.label109.TabIndex = 14;
            this.label109.Text = "Real time";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox3
            // 
            this.guna2CustomCheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox3.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox3.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox3.Location = new System.Drawing.Point(124, 41);
            this.guna2CustomCheckBox3.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox3.Name = "guna2CustomCheckBox3";
            this.guna2CustomCheckBox3.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox3.TabIndex = 13;
            this.guna2CustomCheckBox3.Text = "active";
            this.guna2CustomCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox3.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox3.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label108
            // 
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.Location = new System.Drawing.Point(140, 33);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(124, 27);
            this.label108.TabIndex = 12;
            this.label108.Text = "Anti-Malware";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2CustomCheckBox4
            // 
            this.guna2CustomCheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox4.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox4.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox4.Location = new System.Drawing.Point(15, 41);
            this.guna2CustomCheckBox4.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox4.Name = "guna2CustomCheckBox4";
            this.guna2CustomCheckBox4.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox4.TabIndex = 11;
            this.guna2CustomCheckBox4.Text = "active";
            this.guna2CustomCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox4.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox4.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label111
            // 
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.Location = new System.Drawing.Point(32, 37);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(87, 27);
            this.label111.TabIndex = 9;
            this.label111.Text = "Antivirus";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2Panel13
            // 
            this.guna2Panel13.BackColor = System.Drawing.Color.White;
            this.guna2Panel13.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2Panel13.BorderRadius = 8;
            this.guna2Panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel13.Location = new System.Drawing.Point(0, 36);
            this.guna2Panel13.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Panel13.Name = "guna2Panel13";
            this.guna2Panel13.Size = new System.Drawing.Size(766, 102);
            this.guna2Panel13.TabIndex = 19;
            // 
            // guna2GroupBox1
            // 
            this.guna2GroupBox1.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox1.BorderColor = System.Drawing.Color.White;
            this.guna2GroupBox1.BorderRadius = 8;
            this.guna2GroupBox1.Controls.Add(this.guna2GroupBox3);
            this.guna2GroupBox1.Controls.Add(this.guna2GroupBox2);
            this.guna2GroupBox1.Controls.Add(this.guna2Panel2);
            this.guna2GroupBox1.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2GroupBox1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox1.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox1.Location = new System.Drawing.Point(8, 7);
            this.guna2GroupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox1.Name = "guna2GroupBox1";
            this.guna2GroupBox1.Size = new System.Drawing.Size(766, 168);
            this.guna2GroupBox1.TabIndex = 0;
            this.guna2GroupBox1.Text = "Scan";
            // 
            // guna2GroupBox3
            // 
            this.guna2GroupBox3.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox3.BorderRadius = 8;
            this.guna2GroupBox3.Controls.Add(this.guna2CustomCheckBox2);
            this.guna2GroupBox3.Controls.Add(this.guna2DateTimePicker2);
            this.guna2GroupBox3.Controls.Add(this.label102);
            this.guna2GroupBox3.Controls.Add(this.label103);
            this.guna2GroupBox3.Controls.Add(this.label104);
            this.guna2GroupBox3.Controls.Add(this.guna2Panel3);
            this.guna2GroupBox3.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox3.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox3.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox3.Location = new System.Drawing.Point(290, 40);
            this.guna2GroupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox3.Name = "guna2GroupBox3";
            this.guna2GroupBox3.Size = new System.Drawing.Size(474, 126);
            this.guna2GroupBox3.TabIndex = 2;
            this.guna2GroupBox3.Text = "Partial Scan";
            // 
            // guna2CustomCheckBox2
            // 
            this.guna2CustomCheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox2.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox2.Location = new System.Drawing.Point(146, 102);
            this.guna2CustomCheckBox2.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox2.Name = "guna2CustomCheckBox2";
            this.guna2CustomCheckBox2.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox2.TabIndex = 12;
            this.guna2CustomCheckBox2.Text = "active";
            this.guna2CustomCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox2.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox2.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2DateTimePicker2
            // 
            this.guna2DateTimePicker2.BorderRadius = 15;
            this.guna2DateTimePicker2.Checked = true;
            this.guna2DateTimePicker2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2DateTimePicker2.FillColor = System.Drawing.Color.CornflowerBlue;
            this.guna2DateTimePicker2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker2.ForeColor = System.Drawing.Color.White;
            this.guna2DateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker2.Location = new System.Drawing.Point(147, 67);
            this.guna2DateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.guna2DateTimePicker2.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker2.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker2.Name = "guna2DateTimePicker2";
            this.guna2DateTimePicker2.Size = new System.Drawing.Size(247, 29);
            this.guna2DateTimePicker2.TabIndex = 12;
            this.guna2DateTimePicker2.Value = new System.DateTime(2021, 12, 31, 13, 13, 50, 949);
            // 
            // label102
            // 
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.Location = new System.Drawing.Point(15, 98);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(127, 28);
            this.label102.TabIndex = 11;
            this.label102.Text = "Boot Scan :";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label103
            // 
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.Location = new System.Drawing.Point(15, 72);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(127, 18);
            this.label103.TabIndex = 10;
            this.label103.Text = "Select date :";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label104
            // 
            this.label104.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.label104.Font = new System.Drawing.Font("Segoe UI Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.Location = new System.Drawing.Point(211, 38);
            this.label104.Name = "label104";
            this.label104.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label104.Size = new System.Drawing.Size(40, 23);
            this.label104.TabIndex = 7;
            this.label104.Text = "Path";
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.Controls.Add(this.guna2Button49);
            this.guna2Panel3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2Panel3.Location = new System.Drawing.Point(15, 36);
            this.guna2Panel3.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(358, 27);
            this.guna2Panel3.TabIndex = 29;
            // 
            // guna2GroupBox2
            // 
            this.guna2GroupBox2.BackColor = System.Drawing.Color.White;
            this.guna2GroupBox2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(241)))), ((int)(((byte)(242)))), ((int)(((byte)(246)))));
            this.guna2GroupBox2.BorderRadius = 8;
            this.guna2GroupBox2.Controls.Add(this.guna2CustomCheckBox1);
            this.guna2GroupBox2.Controls.Add(this.guna2DateTimePicker1);
            this.guna2GroupBox2.Controls.Add(this.label100);
            this.guna2GroupBox2.Controls.Add(this.label101);
            this.guna2GroupBox2.CustomBorderColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox2.FillColor = System.Drawing.Color.Transparent;
            this.guna2GroupBox2.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.guna2GroupBox2.ForeColor = System.Drawing.Color.Black;
            this.guna2GroupBox2.Location = new System.Drawing.Point(2, 40);
            this.guna2GroupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.guna2GroupBox2.Name = "guna2GroupBox2";
            this.guna2GroupBox2.Size = new System.Drawing.Size(283, 126);
            this.guna2GroupBox2.TabIndex = 1;
            this.guna2GroupBox2.Text = "Scan Complete";
            // 
            // guna2CustomCheckBox1
            // 
            this.guna2CustomCheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.CheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox1.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2CustomCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2CustomCheckBox1.Location = new System.Drawing.Point(145, 106);
            this.guna2CustomCheckBox1.Margin = new System.Windows.Forms.Padding(2);
            this.guna2CustomCheckBox1.Name = "guna2CustomCheckBox1";
            this.guna2CustomCheckBox1.Size = new System.Drawing.Size(11, 12);
            this.guna2CustomCheckBox1.TabIndex = 11;
            this.guna2CustomCheckBox1.Text = "active";
            this.guna2CustomCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2CustomCheckBox1.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox1.UncheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // guna2DateTimePicker1
            // 
            this.guna2DateTimePicker1.BorderRadius = 15;
            this.guna2DateTimePicker1.Checked = true;
            this.guna2DateTimePicker1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guna2DateTimePicker1.FillColor = System.Drawing.Color.CornflowerBlue;
            this.guna2DateTimePicker1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2DateTimePicker1.ForeColor = System.Drawing.Color.White;
            this.guna2DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.guna2DateTimePicker1.Location = new System.Drawing.Point(14, 62);
            this.guna2DateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.guna2DateTimePicker1.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.guna2DateTimePicker1.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            this.guna2DateTimePicker1.Size = new System.Drawing.Size(250, 29);
            this.guna2DateTimePicker1.TabIndex = 10;
            this.guna2DateTimePicker1.Value = new System.DateTime(2021, 12, 31, 13, 13, 50, 949);
            // 
            // label100
            // 
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.Location = new System.Drawing.Point(12, 101);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(128, 20);
            this.label100.TabIndex = 9;
            this.label100.Text = "Boot Scan :";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label101
            // 
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.Location = new System.Drawing.Point(12, 38);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(186, 22);
            this.label101.TabIndex = 8;
            this.label101.Text = "Select date:";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.BackColor = System.Drawing.Color.White;
            this.guna2Panel2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.guna2Panel2.BorderRadius = 8;
            this.guna2Panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.guna2Panel2.Location = new System.Drawing.Point(0, 38);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.Size = new System.Drawing.Size(766, 130);
            this.guna2Panel2.TabIndex = 4;
            // 
            // aide
            // 
            this.aide.Location = new System.Drawing.Point(0, 0);
            this.aide.Name = "aide";
            this.aide.Size = new System.Drawing.Size(200, 100);
            this.aide.TabIndex = 0;
            // 
            // label117
            // 
            this.label117.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label117.AutoSize = true;
            this.label117.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(249)))), ((int)(((byte)(249)))));
            this.label117.Font = new System.Drawing.Font("Segoe UI Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.Location = new System.Drawing.Point(428, 236);
            this.label117.Name = "label117";
            this.label117.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label117.Size = new System.Drawing.Size(54, 19);
            this.label117.TabIndex = 41;
            this.label117.Text = "Chemin";
            // 
            // label118
            // 
            this.label118.Location = new System.Drawing.Point(0, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(100, 23);
            this.label118.TabIndex = 0;
            // 
            // label119
            // 
            this.label119.Location = new System.Drawing.Point(0, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(100, 23);
            this.label119.TabIndex = 0;
            // 
            // label120
            // 
            this.label120.Location = new System.Drawing.Point(0, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(100, 23);
            this.label120.TabIndex = 0;
            // 
            // label107
            // 
            this.label107.Location = new System.Drawing.Point(0, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(100, 23);
            this.label107.TabIndex = 0;
            // 
            // label106
            // 
            this.label106.Location = new System.Drawing.Point(0, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(100, 23);
            this.label106.TabIndex = 0;
            // 
            // label105
            // 
            this.label105.Location = new System.Drawing.Point(0, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(100, 23);
            this.label105.TabIndex = 0;
            // 
            // guna2GroupBox10
            // 
            this.guna2GroupBox10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox10.Location = new System.Drawing.Point(0, 0);
            this.guna2GroupBox10.Name = "guna2GroupBox10";
            this.guna2GroupBox10.Size = new System.Drawing.Size(300, 200);
            this.guna2GroupBox10.TabIndex = 0;
            // 
            // guna2GroupBox11
            // 
            this.guna2GroupBox11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GroupBox11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.guna2GroupBox11.Location = new System.Drawing.Point(0, 0);
            this.guna2GroupBox11.Name = "guna2GroupBox11";
            this.guna2GroupBox11.Size = new System.Drawing.Size(300, 200);
            this.guna2GroupBox11.TabIndex = 0;
            // 
            // guna2CustomCheckBox12
            // 
            this.guna2CustomCheckBox12.CheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox12.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox12.Location = new System.Drawing.Point(0, 0);
            this.guna2CustomCheckBox12.Name = "guna2CustomCheckBox12";
            this.guna2CustomCheckBox12.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox12.TabIndex = 0;
            this.guna2CustomCheckBox12.UncheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox12.UncheckedState.BorderThickness = 0;
            // 
            // guna2CustomCheckBox13
            // 
            this.guna2CustomCheckBox13.CheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox13.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox13.Location = new System.Drawing.Point(0, 0);
            this.guna2CustomCheckBox13.Name = "guna2CustomCheckBox13";
            this.guna2CustomCheckBox13.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox13.TabIndex = 0;
            this.guna2CustomCheckBox13.UncheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox13.UncheckedState.BorderThickness = 0;
            // 
            // guna2CustomCheckBox14
            // 
            this.guna2CustomCheckBox14.CheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox14.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox14.Location = new System.Drawing.Point(0, 0);
            this.guna2CustomCheckBox14.Name = "guna2CustomCheckBox14";
            this.guna2CustomCheckBox14.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox14.TabIndex = 0;
            this.guna2CustomCheckBox14.UncheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox14.UncheckedState.BorderThickness = 0;
            // 
            // guna2CustomCheckBox15
            // 
            this.guna2CustomCheckBox15.CheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox15.CheckedState.BorderThickness = 0;
            this.guna2CustomCheckBox15.Location = new System.Drawing.Point(0, 0);
            this.guna2CustomCheckBox15.Name = "guna2CustomCheckBox15";
            this.guna2CustomCheckBox15.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox15.TabIndex = 0;
            this.guna2CustomCheckBox15.UncheckedState.BorderRadius = 0;
            this.guna2CustomCheckBox15.UncheckedState.BorderThickness = 0;
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel1.TabIndex = 0;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel4.TabIndex = 0;
            // 
            // guna2Panel5
            // 
            this.guna2Panel5.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel5.Name = "guna2Panel5";
            this.guna2Panel5.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel5.TabIndex = 0;
            // 
            // guna2Panel6
            // 
            this.guna2Panel6.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel6.Name = "guna2Panel6";
            this.guna2Panel6.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel6.TabIndex = 0;
            // 
            // guna2Panel7
            // 
            this.guna2Panel7.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel7.Name = "guna2Panel7";
            this.guna2Panel7.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel7.TabIndex = 0;
            // 
            // guna2Panel8
            // 
            this.guna2Panel8.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel8.Name = "guna2Panel8";
            this.guna2Panel8.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel8.TabIndex = 0;
            // 
            // guna2Panel9
            // 
            this.guna2Panel9.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel9.Name = "guna2Panel9";
            this.guna2Panel9.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel9.TabIndex = 0;
            // 
            // guna2Panel10
            // 
            this.guna2Panel10.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel10.Name = "guna2Panel10";
            this.guna2Panel10.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel10.TabIndex = 0;
            // 
            // guna2Panel11
            // 
            this.guna2Panel11.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel11.Name = "guna2Panel11";
            this.guna2Panel11.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel11.TabIndex = 0;
            // 
            // guna2Panel12
            // 
            this.guna2Panel12.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel12.Name = "guna2Panel12";
            this.guna2Panel12.Size = new System.Drawing.Size(200, 100);
            this.guna2Panel12.TabIndex = 0;
            // 
            // Parametres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1039, 511);
            this.Controls.Add(this.setting);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Parametres";
            this.Text = "Parametres";
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView5)).EndInit();
            this.setting.ResumeLayout(false);
            this.guna2GroupBox9.ResumeLayout(false);
            this.guna2GroupBox12.ResumeLayout(false);
            this.guna2GroupBox13.ResumeLayout(false);
            this.guna2Panel14.ResumeLayout(false);
            this.guna2GroupBox4.ResumeLayout(false);
            this.guna2GroupBox8.ResumeLayout(false);
            this.guna2GroupBox7.ResumeLayout(false);
            this.guna2GroupBox5.ResumeLayout(false);
            this.guna2GroupBox6.ResumeLayout(false);
            this.guna2GroupBox1.ResumeLayout(false);
            this.guna2GroupBox3.ResumeLayout(false);
            this.guna2GroupBox3.PerformLayout();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2GroupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Guna.UI2.WinForms.Guna2Button guna2Button17;
        private Guna.UI2.WinForms.Guna2Button guna2Button50;
        private Guna.UI2.WinForms.Guna2Button guna2Button49;
        private Guna.UI2.WinForms.Guna2Button guna2Button51;
        private Guna.UI2.WinForms.Guna2Button guna2Button52;
        private Guna.UI2.WinForms.Guna2Button restaure;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView5;
        private Guna.UI2.WinForms.Guna2ProgressIndicator custom_ProgressIndicator;
        private Guna.UI2.WinForms.Guna2ProgressBar custom_progressBar;
        private Guna.UI2.WinForms.Guna2Panel setting;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox1;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox2;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox3;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox4;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox5;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox6;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox7;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox8;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox9;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox10;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox11;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox12;
        private Guna.UI2.WinForms.Guna2GroupBox guna2GroupBox13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel5;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel6;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel7;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel8;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel9;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel10;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel11;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel12;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel13;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel14;
        private Guna.UI2.WinForms.Guna2Panel aide;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox1;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox2;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox3;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox4;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox5;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox6;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox7;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox8;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox9;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox10;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox11;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox12;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox13;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox14;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox15;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox16;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox17;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox18;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox19;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox20;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker2;

        //****************label********************************************
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}