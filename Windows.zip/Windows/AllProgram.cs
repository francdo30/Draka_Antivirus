﻿using Microsoft.Win32;
using System;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class AllProgram : Form
    {
        public AllProgram()
        {
            InitializeComponent();


            listView1.View = View.Details;


            string displayName;
            string editName;
            string version;
            RegistryKey key;

            // search in: CurrentUser
            key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            foreach (String keyName in key.GetSubKeyNames())
            {
                RegistryKey subkey = key.OpenSubKey(keyName);
                displayName = subkey.GetValue("DisplayName") as string;
                editName = subkey.GetValue("Publisher") as string;
                version = subkey.GetValue("DisplayVersion") as string;
                //Console.WriteLine(displayName);
                listView1.Items.Add(new ListViewItem(new string[] { displayName, editName, version }));
            }

            // search in: LocalMachine_32
            key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
            foreach (String keyName in key.GetSubKeyNames())
            {
                RegistryKey subkey = key.OpenSubKey(keyName);
                displayName = subkey.GetValue("DisplayName") as string;
                editName = subkey.GetValue("Publisher") as string;
                version = subkey.GetValue("DisplayVersion") as string;
                //Console.WriteLine(displayName);
                listView1.Items.Add(new ListViewItem(new string[] { displayName, editName, version }));
            }

            // search in: LocalMachine_64
            //key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall");
            //foreach (String keyName in key.GetSubKeyNames())
            //{
            //RegistryKey subkey = key.OpenSubKey(keyName);
            //displayName = subkey.GetValue("DisplayName") as string;
            //editName = subkey.GetValue("Publisher") as string;
            //version = subkey.GetValue("DisplayVersion") as string;
            //Console.WriteLine(displayName);
            //listView1.Items.Add(new ListViewItem(new string[] { displayName, editName, version }));
            //}
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Console.WriteLine("AllProgram");

        }
    }
}
