﻿using Draka_Antivirus.Pages_Principales;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class InfosSysteme : Form
    {
        InfoSystem perf = new InfoSystem();
        List<String> item = new List<string>();
        public InfosSysteme()
        {
            InitializeComponent();

            item = perf.CommandeWMI();

            // remplissage des labels pour les informations Systeme

            label16.Text = Environment.MachineName;
            label18.Text = Environment.UserName;


            for (int i = 0; i < item.Count; i++)
            {
                if (i == 0)
                {
                    labelOperatingSystem.Text = item[i];
                }
                if (i == 1)
                {
                    label21.Text = item[i];
                }
                if (i == 2)
                {
                    label24.Text = item[i];
                }
                if (i == 3)         //Vsys
                {
                    label17.Text = item[i];
                }
                if (i == 4)         // Fabrican
                {
                    label20.Text = item[i];
                }
                if (i == 5)          // MonterBoard
                {
                    label2.Text = item[i];
                }
                if (i == 6)          // Number of cores
                {
                    label25.Text = item[i];
                }
                if (i == 7)           //  ClockSpeed
                {
                    label26.Text = item[i];
                }
                if (i == 8)             // processeur
                {
                    label23.Text = item[i];
                }
                if (i == 9)              // processor Load
                {
                    label28.Text = item[i];
                }
                if (i == 10)     // Dgroup
                {
                    label19.Text = item[i];
                }
                if (i == 11)     // video adapter
                {
                    label27.Text = item[i];
                }

            }
        }


        private void label29_Click(object sender, EventArgs e)
        {

        }
    }
}
