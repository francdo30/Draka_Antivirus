﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Performance : Form
    {
        public Performance()
        {
            InitializeComponent();
            openChildrenForm_Performance(new InfosSysteme());
        }

        private Form activeForm = null;
        private void openChildrenForm_Performance(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelBodyPerformance.Controls.Add(childForm);
            panelBodyPerformance.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void guna2Button17_Click(object sender, EventArgs e)
        {
            openChildrenForm_Performance(new InfosSysteme());
        }

        private void guna2Button16_Click(object sender, EventArgs e)
        {
            openChildrenForm_Performance(new Disk());
        }

        private void guna2Button19_Click(object sender, EventArgs e)
        {
            openChildrenForm_Performance(new Memoire());
        }

        private void guna2Button18_Click(object sender, EventArgs e)
        {
            openChildrenForm_Performance(new Reseau());
        }
    }
}
