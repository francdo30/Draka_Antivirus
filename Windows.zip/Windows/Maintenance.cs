﻿using Draka_Antivirus.Windows;
using System;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Maintenance : Form
    {
        public Maintenance()
        {
            InitializeComponent();
            openChildrenForm_Maintenance(new Recycle());
        }


        private Form activeForm = null;
        private void openChildrenForm_Maintenance(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelBodyMaintenance.Controls.Add(childForm);
            panelBodyMaintenance.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnRecycle_Click(object sender, EventArgs e)
        {
            openChildrenForm_Maintenance(new Recycle());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildrenForm_Maintenance(new TemporyFile());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildrenForm_Maintenance(new StartupSoftware());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            openChildrenForm_Maintenance(new Update());
        }
    }
}
