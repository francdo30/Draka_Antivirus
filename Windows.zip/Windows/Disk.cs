﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Disk : Form
    {
        public Disk()
        {
            InitializeComponent();
            // Part Disk 
            DriveInfo[] allDrives = DriveInfo.GetDrives();
            listView1.View = View.Details;
            resizing();
            int count = 0;
            foreach (DriveInfo d in allDrives)
            {
                if (d.IsReady == true)
                {
                    double free, total;
                    free = d.TotalFreeSpace / Math.Pow(1024, 3);
                    total = d.TotalSize / Math.Pow(1024, 3);
                    listView1.Items.Add(new ListViewItem(new string[] { d.Name, d.DriveType.ToString(), d.VolumeLabel, d.DriveFormat, Math.Round(free, 2) + " GB", Math.Round(total, 2) + " GB" }));
                }

                count++;
            }
            // End Part Disk 
        }

        public void resizing()
        {
            float totalColumnWidth = 0;

            // Get the sum of all column tags
            for (int i = 0; i < listView1.Columns.Count; i++)
                totalColumnWidth += Convert.ToInt32(listView1.Columns[i].Tag);

            // Calculate the percentage of space each column should 
            // occupy in reference to the other columns and then set the 
            // width of the column to that percentage of the visible space.
            for (int i = 0; i < listView1.Columns.Count; i++)
            {
                float colPercentage = (Convert.ToInt32(listView1.Columns[i].Tag) / totalColumnWidth);
                listView1.Columns[i].Width = (int)(colPercentage * listView1.ClientRectangle.Width);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
