﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Home : Form
    {
        private Form activeForm = null;
        public Home()
        {
            InitializeComponent();

        }
        void openChildrenForm2(Form childForm)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            //Index in = new Index();
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panel1.Controls.Add(childForm);
            this.panel1.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
            //labelInfosbtn.Text = childForm.Text;

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            /*home1.Show();
            home1.BringToFront();*/
            //openChildrenForm2(new Fenetres.Autres.PPscan());
        }

    }
}
