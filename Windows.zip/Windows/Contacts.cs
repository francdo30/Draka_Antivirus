﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class Contacts : Form
    {
        public Contacts()
        {
            InitializeComponent();
        }

        private void roundedButton1_Click(object sender, EventArgs e)
        {
            if (guna2TextBox3.Text == guna2TextBox4.Text)
            {
                if (guna2TextBox7.Text == "")
                {
                    string file = "";
                    if (checkBox1.Checked)
                    {
                        file = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
                        notificationClient(guna2TextBox3.Text, guna2TextBox4.Text, guna2TextBox5.Text, guna2TextBox5.Text, label117.Text, file);
                    }
                    else
                    {
                        notificationClient(guna2TextBox3.Text, guna2TextBox4.Text, guna2TextBox5.Text, guna2TextBox5.Text, label117.Text, "");
                    }
                }
                else
                {
                    string file = "";
                    if (checkBox1.Checked)
                    {
                        file = @"Draka Antivirus\Draka Antivirus\Draka Antivirus\bin\Debug\Error_Log.txt";
                        notificationClient(guna2TextBox3.Text, guna2TextBox4.Text, guna2TextBox5.Text, guna2TextBox5.Text, label117.Text, file);
                    }
                    else
                    {
                        notificationClient(guna2TextBox3.Text, guna2TextBox4.Text, guna2TextBox5.Text, guna2TextBox5.Text, label117.Text, "");
                    }
                }
            }
        }

        // Mail notification
        public void notificationClient(string clientmail, string clientName, string phone, string messages, string filepath, string filepath1)
        {
            Attachment data = new Attachment(filepath, MediaTypeNames.Application.Octet);
            Attachment data1 = new Attachment(filepath1, MediaTypeNames.Application.Octet);

            MailAddress to = new MailAddress(clientmail);
            MailAddress from = new MailAddress("support @drakashield.com");

            MailMessage message = new MailMessage(from, to);
            message.Subject = "Client contacts";
            message.Body = "Bonjour Je me nomme Mr/Mme" + clientName + " " +
                "\t Tel : " + phone + " " +
                "\t Message : " + messages;
            message.Attachments.Add(data);
            message.Attachments.Add(data1);

            SmtpClient client = new SmtpClient("smtp.server.address", 465)
            {
                Credentials = new NetworkCredential("supportshield@drakashield.com", "smtp_password"),
                EnableSsl = true
            };
            // code in brackets above needed if authentication required

            try
            {
                client.Send(message);
            }
            catch (SmtpException ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }


        private void guna2Button51_Click(object sender, EventArgs e)
        {
            label117.Text = folderBrowserDialog1.SelectedPath;
        }

        private void label118_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button52_Click(object sender, EventArgs e)
        {
           // MessageBox("Page en Maintenance");
        }
    }
}
