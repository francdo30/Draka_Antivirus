﻿namespace Draka_Antivirus.Windows
{
    partial class Stability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelBodyStability = new System.Windows.Forms.Panel();
            this.panelMenuPerfermance = new System.Windows.Forms.Panel();
            this.btnEventLog = new Guna.UI2.WinForms.Guna2Button();
            this.button2 = new Guna.UI2.WinForms.Guna2Button();
            this.button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnAllProgram = new Guna.UI2.WinForms.Guna2Button();
            this.panelMenuPerfermance.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelBodyStability
            // 
            this.panelBodyStability.BackColor = System.Drawing.Color.White;
            this.panelBodyStability.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodyStability.Location = new System.Drawing.Point(208, 0);
            this.panelBodyStability.Margin = new System.Windows.Forms.Padding(4);
            this.panelBodyStability.Name = "panelBodyStability";
            this.panelBodyStability.Size = new System.Drawing.Size(831, 511);
            this.panelBodyStability.TabIndex = 3;
            // 
            // panelMenuPerfermance
            // 
            this.panelMenuPerfermance.BackColor = System.Drawing.Color.White;
            this.panelMenuPerfermance.Controls.Add(this.btnEventLog);
            this.panelMenuPerfermance.Controls.Add(this.button2);
            this.panelMenuPerfermance.Controls.Add(this.button1);
            this.panelMenuPerfermance.Controls.Add(this.btnAllProgram);
            this.panelMenuPerfermance.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenuPerfermance.Location = new System.Drawing.Point(0, 0);
            this.panelMenuPerfermance.Margin = new System.Windows.Forms.Padding(4);
            this.panelMenuPerfermance.Name = "panelMenuPerfermance";
            this.panelMenuPerfermance.Size = new System.Drawing.Size(208, 511);
            this.panelMenuPerfermance.TabIndex = 2;
            // 
            // btnEventLog
            // 
            this.btnEventLog.Animated = true;
            this.btnEventLog.BorderRadius = 10;
            this.btnEventLog.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEventLog.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnEventLog.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnEventLog.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnEventLog.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnEventLog.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnEventLog.ForeColor = System.Drawing.Color.White;
            this.btnEventLog.Location = new System.Drawing.Point(7, 382);
            this.btnEventLog.Margin = new System.Windows.Forms.Padding(2);
            this.btnEventLog.Name = "btnEventLog";
            this.btnEventLog.Size = new System.Drawing.Size(195, 56);
            this.btnEventLog.TabIndex = 6;
            this.btnEventLog.Text = "Event log alerts";
            this.btnEventLog.Click += new System.EventHandler(this.btnEventLog_Click);
            // 
            // button2
            // 
            this.button2.Animated = true;
            this.button2.BorderRadius = 10;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(7, 282);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(195, 56);
            this.button2.TabIndex = 6;
            this.button2.Text = "Crashing programs ∙ Event log alerts";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Animated = true;
            this.button1.BorderRadius = 10;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(7, 182);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(195, 56);
            this.button1.TabIndex = 6;
            this.button1.Text = "Windows restore point";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAllProgram
            // 
            this.btnAllProgram.Animated = true;
            this.btnAllProgram.BorderRadius = 10;
            this.btnAllProgram.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAllProgram.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAllProgram.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAllProgram.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAllProgram.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAllProgram.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnAllProgram.ForeColor = System.Drawing.Color.White;
            this.btnAllProgram.Location = new System.Drawing.Point(7, 86);
            this.btnAllProgram.Margin = new System.Windows.Forms.Padding(2);
            this.btnAllProgram.Name = "btnAllProgram";
            this.btnAllProgram.Size = new System.Drawing.Size(195, 56);
            this.btnAllProgram.TabIndex = 6;
            this.btnAllProgram.Text = "All the programs";
            this.btnAllProgram.Click += new System.EventHandler(this.btnAllProgram_Click);
            // 
            // Stability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1039, 511);
            this.Controls.Add(this.panelBodyStability);
            this.Controls.Add(this.panelMenuPerfermance);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Stability";
            this.Text = "Stability";
            this.panelMenuPerfermance.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelBodyStability;
        private System.Windows.Forms.Panel panelMenuPerfermance;
        private Guna.UI2.WinForms.Guna2Button btnEventLog;
        private Guna.UI2.WinForms.Guna2Button button2;
        private Guna.UI2.WinForms.Guna2Button button1;
        private Guna.UI2.WinForms.Guna2Button btnAllProgram;
    }
}