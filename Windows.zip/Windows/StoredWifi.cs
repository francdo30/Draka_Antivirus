﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace Draka_Antivirus.Windows
{
    public partial class StoredWifi : Form
    {
        public StoredWifi()
        {
            InitializeComponent();
        }

        int wifiCount = 0;
        int Wifi_count_names = 0;

        private string GetWifiNetworks()
        {
            //execute the netsh command using process class
            Process processWifi = new Process();
            processWifi.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            processWifi.StartInfo.FileName = "netsh";
            processWifi.StartInfo.Arguments = "wlan show profile";

            processWifi.StartInfo.UseShellExecute = false;
            processWifi.StartInfo.RedirectStandardError = true;
            processWifi.StartInfo.RedirectStandardInput = true;
            processWifi.StartInfo.RedirectStandardOutput = true;
            processWifi.StartInfo.CreateNoWindow = true;
            processWifi.Start();

            string output = processWifi.StandardOutput.ReadToEnd();

            processWifi.WaitForExit();
            return output;
        }

        private string ReadPassword(string Wifi_Name)
        {

            string argument = "wlan show profile name=\"" + Wifi_Name + "\" key=clear";
            Process processWifi = new Process();
            processWifi.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            processWifi.StartInfo.FileName = "netsh";
            processWifi.StartInfo.Arguments = argument;


            processWifi.StartInfo.UseShellExecute = false;
            processWifi.StartInfo.RedirectStandardError = true;
            processWifi.StartInfo.RedirectStandardInput = true;
            processWifi.StartInfo.RedirectStandardOutput = true;
            processWifi.StartInfo.CreateNoWindow = true;
            processWifi.Start();

            string output = processWifi.StandardOutput.ReadToEnd();
            processWifi.WaitForExit();
            return output;
        }

        private string GetWifiPassword(string Wifi_Name)
        {
            string get_password = ReadPassword(Wifi_Name.Trim());
            using (StringReader reader = new StringReader(get_password))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Contains("Contenu de la") || line.Contains("Key Content"))
                    {
                        string current_password = line.Substring(line.IndexOf(":") + 1).Trim();
                        return current_password;
                    }
                }
            }
            return "Open Network - NO PASSWORD";
        }

        private string GetAutentication(string Wifi_Name)
        {
            string get_Auth = ReadPassword(Wifi_Name.Trim());
            using (StringReader reader = new StringReader(get_Auth))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Contains("Authentification") || line.Contains("Authentication"))
                    {
                        string current_Auth = line.Substring(line.IndexOf(":") + 1).Trim();
                        return current_Auth;
                    }
                }
            }
            return "None";
        }

        // main Method 
        private void get_Wifi_passwords()
        {
            string WifiNetworks = GetWifiNetworks();
            using (StringReader reader = new StringReader(WifiNetworks))
            {

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    wifiCount++;
                    string wifi = line.Substring(line.IndexOf(":") + 1);
                    if ((wifi.Trim() != "") && (wifi != line))
                    {
                        labelInfo.Visible = false;
                        Wifi_count_names++;
                        string Wifi_name = wifi;
                        string Wifi_password = GetWifiPassword(Wifi_name);
                        string Wifi_authentication = GetAutentication(Wifi_name);
                        dgvWifiNetworks.Rows.Add(new Object[] { "", Wifi_name, Wifi_authentication == "Ouvrir" ? "Open" : Wifi_authentication, Wifi_password });

                    }
                }
            }


        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            btnScan.Enabled = false;
            dgvWifiNetworks.Rows.Clear();
            get_Wifi_passwords();
            if (dgvWifiNetworks.Rows.Count <= 0)
            {
                labelInfo.Visible = true;
                labelInfo.Text = "There is no wifi password stored on this computer !";
            }
            btnScan.Enabled = true;
        }

        private void StoredWifi_Load(object sender, EventArgs e)
        {

        }
    }
}
